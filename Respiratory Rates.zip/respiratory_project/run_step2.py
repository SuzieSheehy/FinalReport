"""Run and document R-peak detection on eight supplied Apnea-ECG records.

Usage from project root:
    python run_step2.py --data-zip data.zip

Writes:
    results/qrs_detection_metrics.csv
    figures/fig_r_peak_detection_a01.png, .pdf
    figures/fig_qrs_f1_comparison.png, .pdf
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from src.ecg_io import load_record
from src.rpeaks import detect_r_peaks, evaluate_r_peaks
from src.output_utils import stage_run

# Preselected representative records include difficult cases: a02 and b05.
DEFAULT_RECORDS = ['a01', 'a02', 'a05', 'b01', 'b05', 'c01', 'c05', 'x01']


def create_outputs(data_zip: Path, records: list[str], outdir: Path) -> list[dict]:
    parameters = {'data_zip': str(data_zip), 'records': records,
                  'matching_tolerance_s': .12}
    with stage_run(outdir, 'step2', parameters):
        return _create_outputs(data_zip, records, outdir, parameters['matching_tolerance_s'])


def _create_outputs(data_zip: Path, records: list[str], outdir: Path,
                    tolerance_s: float) -> list[dict]:
    figdir = outdir / 'figures'
    resdir = outdir / 'results'
    figdir.mkdir(parents=True, exist_ok=True)
    resdir.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []

    for name in records:
        record = load_record(data_zip, name)
        predicted = detect_r_peaks(record.ecg_mv, record.fs)
        metrics = evaluate_r_peaks(predicted, record.qrs_samples, record.fs,
                                   tolerance_seconds=tolerance_s)
        entry = {'record': name, 'n_annotations': len(record.qrs_samples),
                 'n_detections': len(predicted),
                 'TP': metrics.true_positive,
                 'FP': metrics.false_positive,
                 'FN': metrics.false_negative,
                 'precision': round(metrics.precision, 6),
                 'recall': round(metrics.recall, 6),
                 'F1': round(metrics.f1_score, 6),
                 'median_offset_ms': metrics.median_time_offset_ms,
                 'p95_abs_offset_ms': metrics.p95_absolute_time_offset_ms}
        rows.append(entry)
        print(f'{name}: TP={entry["TP"]}, FP={entry["FP"]}, FN={entry["FN"]}, '
              f'Precision={metrics.precision:.4f}, Recall={metrics.recall:.4f}, '
              f'F1={metrics.f1_score:.4f}')

        if name == 'a01':
            start, end = 774.0, 786.0
            i0, i1 = int(start * record.fs), int(end * record.fs)
            t = np.arange(i0, i1) / record.fs
            sig = record.ecg_mv[i0:i1]
            sel = predicted[(predicted >= i0) & (predicted < i1)]
            qrs = record.qrs_samples[(record.qrs_samples >= i0) &
                                     (record.qrs_samples < i1)]
            fig, ax = plt.subplots(figsize=(12, 4.4))
            ax.plot(t, sig, lw=1.0, color='#16395d', label='ECG waveform')
            ax.vlines(qrs / record.fs, *ax.get_ylim(), lw=1.2,
                      linestyle=':', color='tab:red', alpha=0.65,
                      label='Reference QRS location')
            ax.scatter(sel / record.fs, record.ecg_mv[sel],
                       marker='o', s=28, color='tab:green', zorder=5,
                       label='Automatically detected R peak')
            ax.set_xlim(start, end)
            ax.set_xlabel('Time (s)')
            ax.set_ylabel('ECG amplitude (mV)')
            ax.set_title('Record a01: automatic R peaks vs reference QRS annotations')
            ax.legend(loc='upper right', fontsize=8)
            ax.grid(alpha=0.2)
            fig.tight_layout()
            for ext in ['png', 'pdf']:
                fig.savefig(figdir / f'fig_r_peak_detection_a01.{ext}', dpi=170)
            plt.close(fig)

    cols = list(rows[0].keys())
    with (resdir / 'qrs_detection_metrics.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)

    fig, ax = plt.subplots(figsize=(9, 4))
    ax.bar([r['record'] for r in rows], [r['F1'] for r in rows])
    ax.set_ylim(0, 1.04)
    ax.set_ylabel('F1 score (matching tolerance: ±0.12 s)')
    ax.set_xlabel('Record')
    ax.set_title('R-peak detection: per-record agreement with QRS annotations')
    ax.grid(axis='y', alpha=0.25)
    fig.tight_layout()
    for ext in ['png', 'pdf']:
        fig.savefig(figdir / f'fig_qrs_f1_comparison.{ext}', dpi=170)
    plt.close(fig)
    return rows


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-zip', type=Path, default=Path('data.zip'))
    parser.add_argument('--records', nargs='+', default=DEFAULT_RECORDS)
    parser.add_argument('--output-dir', type=Path, default=Path('.'))
    args = parser.parse_args()
    create_outputs(args.data_zip, args.records, args.output_dir)
    print('Output saved to figures/ and results/.')
