"""One-command reproduction of the numerical results and report figures.

This driver deliberately runs the four stages sequentially and stops on any
nonzero return code; it never silently substitutes precomputed output.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import sys
from importlib.metadata import version
import platform
from src.output_utils import STAGE_ARTIFACTS, clean_outputs, timestamp, write_json

ROOT = Path(__file__).resolve().parent


def run_checked(args: list[str]) -> None:
    print("\n$", " ".join(args), flush=True)
    subprocess.run(args, check=True, cwd=ROOT)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-zip', type=Path, default=Path('data.zip'))
    parser.add_argument('--skip-tests', action='store_true')
    parser.add_argument('--output-dir', type=Path, default=Path('.'),
                        help='Output root; use a new directory to retain earlier runs')
    args = parser.parse_args()
    if not args.data_zip.is_file():
        parser.error(f'Data archive not found: {args.data_zip}')
    data_zip = args.data_zip.resolve()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    python = sys.executable
    status = {'status': 'running', 'started_at': timestamp(),
              'data_zip': str(data_zip), 'output_dir': str(output),
              'skip_tests': args.skip_tests, 'python': platform.python_version(),
              'packages': {name: version(name) for name in
                           ('numpy', 'scipy', 'matplotlib', 'pytest')},
              'completed_stages': [], 'commands': []}
    status_path = output/'run_status.json'
    write_json(status_path, status)
    stages = [
        ('run_step1.py', ['--record', 'a01', '--start', '774', '--end', '786']),
        ('run_step2.py', []),
        ('run_step3.py', ['--record', 'a01', '--start', '660', '--duration', '180']),
        ('run_step4.py', []),
    ]
    commands = []
    if not args.skip_tests:
        commands.append(('tests', [python, '-m', 'pytest', '-q']))
    for script, extra in stages:
        destination = output/'figures' if script == 'run_step1.py' else output
        commands.append((script, [python, str(ROOT/script), '--data-zip', str(data_zip),
                                  '--output-dir', str(destination), *extra]))
    commands.append(('make_report_tables.py', [python, str(ROOT/'make_report_tables.py'),
                    '--input-dir', str(output/'results'), '--output-dir', str(output/'tables')]))
    try:
        patterns = [p for owned in STAGE_ARTIFACTS.values() for p in owned]
        patterns += [f'results/step{i}_metadata.json' for i in (2, 3, 4)]
        clean_outputs(output, patterns)
        for stage, command in commands:
            status['current_stage'] = stage
            status['commands'].append(command)
            write_json(status_path, status)
            run_checked(command)
            status['completed_stages'].append(stage)
    except BaseException as exc:
        status.update(status='failed', finished_at=timestamp(),
                      error=f'{type(exc).__name__}: {exc}')
        write_json(status_path, status)
        raise
    status.update(status='success', finished_at=timestamp())
    write_json(status_path, status)
    print(f'\nAll analyses finished. Outputs: {output}', flush=True)


if __name__ == '__main__':
    main()
