# Respiratory Rates — COMP90072 Project Software

**Author:** Xudong Liu  
**Purpose:** Reproduce the data handling, adaptive QRS detection, R--R interval analysis, synthetic and interpolation checks, and exploratory comparisons included in the accompanying final report.

## Data provenance and input layout

The original ECG dataset is the **PhysioNet Apnea-ECG Database** (Penzel et al., 2000): https://physionet.org/content/apnea-ecg/1.0.0/ . It is not bundled in this small source-code submission. To reproduce the results, place the course-supplied `data.zip` at the **project root** (the same directory as `run_all.py`). The ZIP must contain `data/a01.dat`, `data/a01.hea`, `data/a01.qrs`, `data/a01.apn`, etc.; **do not extract it**. You may also pass an absolute or relative path with `--data-zip`.

Expected layout:

```text
respiratory_project/
  data.zip                    # user-supplied, not included in the software archive
  README.md
  requirements.txt
  run_all.py
  run_step1.py ... run_step4.py
  make_report_tables.py
  src/                        # processing implementations
  tests/                      # independent unit tests
  results/                    # reproduced CSV summaries
  figures/                    # reproduced PNG and PDF plots
  tables/                     # LaTeX fragments regenerated from results/
```

The course data archive contains 70 single-lead waveform/header/QRS records and 35 records with minute-level apnea labels. The reference QRS annotations are machine-generated. The `.apn` labels **are not direct respiratory-rate measurements**.

## Dependencies

- Python >=3.10, CPython
- NumPy >=1.26,<3
- SciPy >=1.11,<2
- Matplotlib >=3.7,<4
- pytest >=7,<10 (tests only)

The `requirements.txt` file specifies the supported dependency ranges. The complete workflow and all 35 tests were verified with Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, Matplotlib 3.10.8 and pytest 9.1.1. Floating-point output and graphics can vary slightly between package versions.

Install from the project root:

```bash
python -m pip install -r requirements.txt
```

## One-command reproduction

```bash
python run_all.py --data-zip data.zip
```

This runs the automated test suite, then all four analysis steps, then generates all seven Expanded-report LaTeX tables in `tables/`. A non-zero result from any step stops the driver immediately. To avoid repeating unit tests while debugging, append `--skip-tests`.

To keep the bundled outputs and earlier runs, choose a new output directory:

```bash
python run_all.py --data-zip data.zip --output-dir runs/check_01
```

The chosen output root contains `figures/`, `results/`, `tables/` and
`run_status.json`. The status records commands, package versions, completed
stages and `running`, `success` or `failed`. Only a successful run is a completed
reproduction. Do not run two processes into the same output directory.

Before rerunning in an existing output directory, the driver removes only its
known generated artifacts. Individual Steps 2--4 likewise invalidate their own
previous outputs and dependent LaTeX tables. Unrelated files and input data are
preserved. Step 3 fails if its required real-window spectrum cannot be
computed; it does not silently keep an older plot. Step 4 writes fixed CSV
headers even when no windows are skipped or accepted. If all windows fail,
rejection reasons are saved and the command exits with an error.

`results/step2_metadata.json` through `step4_metadata.json` record parameters
and stage status. Bundled metadata retains the settings from the verified
analysis; machine-specific input paths are omitted from this submission. Captions use these parameters together with actual CSV row
counts. The table generator refuses data from a failed/incomplete stage. For
legacy CSVs without metadata, it omits configuration details that cannot be
recovered rather than assuming the default experiment. For a separate run:

```bash
python make_report_tables.py --input-dir runs/check_01/results --output-dir runs/check_01/tables
```

Step 3 also accepts `--holdout-stride` (default 7); changing it updates the
saved configuration and interpolation caption. Step 1's standalone
`--output-dir` denotes the figure directory itself; Steps 2--4 use an output
root with `figures/` and `results/` underneath. The driver handles this distinction.

**JupyterLab alternative:** set the notebook current directory to the project root and then run:

```python
import subprocess, sys
subprocess.run([sys.executable, "run_all.py", "--data-zip", "data.zip"], check=True)
```

The scripts can be run individually. The following commands use the default report configuration:

```bash
python -m pytest -q
python run_step1.py --data-zip data.zip --record a01 --start 774 --end 786
python run_step2.py --data-zip data.zip
python run_step3.py --data-zip data.zip --record a01 --start 660 --duration 180
python run_step4.py --data-zip data.zip --records a05 a10 b05 c01 --duration-s 180 --max-per-label 4
python make_report_tables.py
```

## Report-result provenance

| Expanded report item | Script and arguments | Reproduced artifact |
|---|---|---|
| Figure 2.1: ECG with QRS/apnea annotations | Step 1, `--record a01 --start 774 --end 786` | `figures/fig_ecg_annotations_a01.pdf` |
| Figure 3.1 and Table 3.1: detection overlay and scores | Step 2, default records, matching tolerance ±0.12 s; table generator | `figures/fig_r_peak_detection_a01.pdf`, `results/qrs_detection_metrics.csv`, `tables/qrs_performance.tex` |
| Table 3.2: matched-beat timing offsets | Step 2 CSV fields `median_offset_ms`, `p95_abs_offset_ms`; `timing_offsets_table()` in the table generator | `results/qrs_detection_metrics.csv`, `tables/timing_offsets.tex` |
| Figure 3.2: a01 R--R tachogram | Step 3, a01, 660--840 s | `figures/fig_rr_tachogram_a01.pdf` |
| Figure 3.3 and Table 3.3: interpolation holdout | Step 3, default stride=7; table generator | `results/rr_interpolation_validation.csv`, `tables/interpolation.tex`, `figures/fig_interpolation_validation_a01.pdf` |
| Table 3.4: synthetic frequency recovery | Step 3, default parameters; table generator | `results/rr_synthetic_frequency_validation.csv`, `tables/synthetic.tex` |
| Figure 3.4: a01 Welch/Lomb spectra | Step 3, default window | `results/rr_candidate_spectra.csv`, `figures/fig_rr_spectra_a01.pdf` |
| Table 3.5: window-level method agreement | Step 4, default records and 180-s windows; table generator | `results/rr_window_metrics.csv`, `tables/consistency.tex` |
| Table 3.6: rejected windows and reasons | Step 4 rejection CSV and window-duration metadata; `rejected_windows_table()` in the table generator | `results/rr_skipped_windows.csv`, `tables/rejected_windows.tex` |
| Table 3.7: per-record and label medians | Step 4, up to four windows per label and record; table generator | `results/rr_window_summary.csv`, `tables/window_summary.tex` |
| Figure 3.5: method-difference histograms | Step 4, same windows | `figures/fig_method_sensitivity.pdf` |
| Figure 3.6: normal/apnea candidate frequencies | Step 4, same windows | `figures/fig_candidate_frequency_by_label.pdf` |

The accompanying report uses the figure PDFs and generated LaTeX table fragments. If any experiment parameters are changed, first rerun the analysis scripts, regenerate the tables, and then transfer the modified outputs into the report project's `figures/` and `tables/` directories before recompiling.

`make_report_tables.py` generates all seven tables and is called by `run_all.py`.
The rejection table handles both an empty CSV with headers and unfamiliar reason
text, escaping LaTeX special characters. Its duration comes from Step 4 metadata.
Steps 2 and 4 invalidate the corresponding timing and rejection tables when rerun.
The spectra and histogram titles and axis text match the Expanded report.
The software also saves three extra diagnostic plots not included in the report.

## Algorithm summary, important assumptions and limitations

1. **ECG loading:** parse raw WFDB format-16 samples and convert using header gain/baseline. Parse WFDB two-byte annotations and 32-bit SKIP extensions; `.qrs` code 16 denotes an artefact, not a valid peak.
2. **QRS detection:** 3rd-order Butterworth bandpass 5--20 Hz, absolute-filtered signal, local quantile/median thresholds in 60-s blocks, 0.35-s refractory separation. It is not calibrated against unseen datasets.
3. **Reference scoring:** ordered, one-to-one pairing of automatic peaks with machine QRS annotations using a ±0.12 s tolerance. Precision/recall/F1 measure QRS agreement **only**.
4. **R--R cleaning:** use peak-pair midpoints for irregular timestamps; retain intervals in [0.35, 2] s within 40% of the local 11-point median.
5. **Resampling:** linear or PCHIP at 4 Hz, without extrapolation or internal bridging of gaps >3 s. Both observed gap endpoints are retained; only the unsupported interior is missing. Reject windows with <95% finite grid coverage or unresolved internal missingness. The analysis grid is not independent 4-Hz clinical data.
6. **Candidate spectral peaks:** Welch on interpolated/detrended intervals versus Lomb--Scargle directly on irregular timestamps. Search 0.10--0.40 Hz; multiply by 60 to present cycles/min. **There is no real-data independent breathing-rate reference in this analysis.**
7. **Normal/apnea descriptive analyses:** stratified, non-overlapping 180-s windows, at most four per label/record. Do not interpret the selected set as patient-level diagnostic performance, apnea prevalence or independent participant sampling.

Spectral inputs must be finite and ordered. Constant and numerically near-constant
detrended R--R series are rejected, as are Welch inputs whose actually used
segments contain only roundoff-level residuals. The numerical floor is
`100 * machine_epsilon * max(1 second, max(abs(RR)))`; it is not an empirically
validated physiological or signal-to-noise threshold. Finite positive spectral
power is checked before normalization and peak selection. Noise and weak
oscillations can still produce candidates: **no peak-significance or respiratory
accuracy test is implemented**.

The spectral settings are: the default 180-s, 4-Hz grid has 720
points; Welch uses a periodic Hann window, a maximum segment length of 512,
50% overlap and linear segment detrending, with no zero padding. Only one
complete segment fits (the first 128 s). Lomb--Scargle uses the retained
irregular observations across 180 s after fitting and removing a linear trend,
on 601 frequencies from 0.10 to 0.40 Hz. Their frequency grid spacings are
0.46875 and 0.03 cycles/min, respectively; these are not accuracy guarantees.
Additional respiratory channels exist for some Apnea-ECG records, but this
workflow does not analyse them.

### Terminology

The CSV keys `sdnn_ms` and `median_sdnn_ms` represent the sample standard deviation of cleaned, non-interpolated R-R intervals within each analysis window and its group median, respectively, in milliseconds.

These field names are used for CSV compatibility. The report, generated summary table, variability histogram and terminal summaries use the term "cleaned-RR SD". This measure should not be interpreted as clinical SDNN because normal sinus beats were not independently classified.

## Tests, efficiency and robustness

Run `python -m pytest -q` to execute the 35 automated tests. The table-output tests also cover all seven tables, current timing values, empty rejection files and unfamiliar rejection reasons. Tests cover WFDB parsing, synthetic peak detection and scoring, R--R cleaning, interpolation and gap handling, spectral recovery and window selection. Plots use Matplotlib's noninteractive `Agg` backend. Peak detection uses finite-memory blocks; spectra use per-window intervals instead of entire recordings. Substantial false positives on a02 and false negatives on b05 are **not** hidden or omitted from the reported table.

Additional tests cover observed long-gap endpoints, constant and numerical
roundoff inputs, trend-only inputs, a constant Welch segment followed by later
modulation, a small resolved off-grid sinusoid, non-finite timestamps, empty
and stale CSVs, failed-stage status, dynamic captions and detections at 60-s
block boundaries. These tests check software behavior and numerical edge cases; they do not
validate weak/noisy respiratory-rate estimates.

## Source file roles

- `src/ecg_io.py`: decode ECG waveforms and annotations from the supplied ZIP.
- `src/rpeaks.py`: adaptive R-peak detection and one-to-one annotation matching.
- `src/rr_analysis.py`: R--R quality control, interpolation, Welch/Lomb spectra, holdout and synthetic verification.
- `src/window_analysis.py`: homogeneous apnea/normal minute labels, reproducible stratified window selection, per-record summaries.
- `src/output_utils.py`: generated-output cleanup, CSV headers and stage metadata/status.
- `run_step1.py` through `run_step4.py`: executable analysis stages.
- `make_report_tables.py`: CSV-to-LaTeX summary tables (no manually entered results).
- `run_all.py`: reproducible driver and failure checking.

## References

Penzel, T. et al. (2000), *The Apnea-ECG Database*, Computers in Cardiology 27, 255--258.  
PhysioNet, *WFDB Applications Guide*: https://physionet.org/physiotools/wag/ .  
Charlton, P. H. et al. (2016), *An assessment of algorithms to estimate respiratory rate from the electrocardiogram and photoplethysmogram*, Physiological Measurement 37, 610--626 (DOI 10.1088/0967-3334/37/4/610).

SciPy documentation: [Welch](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.welch.html)
and [Lomb--Scargle](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.lombscargle.html).
