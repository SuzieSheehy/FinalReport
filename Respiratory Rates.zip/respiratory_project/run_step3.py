"""R--R tachogram, interpolation validation and spectral cross-check.

Reproduce from project root:
  python run_step3.py --data-zip data.zip --record a01 --start 660

Files:
  figures/fig_rr_tachogram_a01.png/.pdf
  figures/fig_interpolation_validation_a01.png/.pdf
  figures/fig_rr_spectra_a01.png/.pdf
  results/rr_interpolation_validation.csv
  results/rr_synthetic_frequency_validation.csv
  results/rr_candidate_spectra.csv

Important: frequencies found in recorded ECG-derived tachograms are only
candidate respiratory-related periodicities: this analysis does not use an
independent respiratory signal. Additional respiratory channels are available
for some records in the broader Apnea-ECG database.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from src.ecg_io import load_record, apnea_status
from src.rpeaks import detect_r_peaks
from src.rr_analysis import (rr_from_peaks, spectral_comparison,
                             simulated_beats, interpolation_holdout)
from src.output_utils import write_csv, stage_run


def save_figure(fig, output: Path) -> None:
    fig.tight_layout()
    for ext in ('png', 'pdf'):
        fig.savefig(output.with_suffix('.'+ext), dpi=170)
    plt.close(fig)


def main(data_zip: Path, record_name: str, start: float, duration: float,
         output_dir: Path, holdout_stride: int = 7) -> None:
    parameters = {'data_zip': str(data_zip), 'record': record_name,
                  'start_s': start, 'duration_s': duration,
                  'holdout_stride': holdout_stride,
                  'fs_grid_hz': 4., 'max_gap_s': 3.,
                  'frequency_band_hz': [.10, .40], 'welch_nperseg_max': 512,
                  'synthetic_frequencies_hz': [.15, .22, .32]}
    with stage_run(output_dir, 'step3', parameters):
        _analyse(data_zip, record_name, start, duration, output_dir, holdout_stride)


def _analyse(data_zip: Path, record_name: str, start: float, duration: float,
             output_dir: Path, holdout_stride: int) -> None:
    output_fig = output_dir / 'figures'
    output_res = output_dir / 'results'
    output_fig.mkdir(exist_ok=True, parents=True)
    output_res.mkdir(exist_ok=True, parents=True)

    record = load_record(data_zip, record_name)
    peaks = detect_r_peaks(record.ecg_mv, record.fs)
    predicted = rr_from_peaks(peaks, record.fs)
    reference = rr_from_peaks(record.qrs_samples, record.fs)
    print(f'ECG record: {record_name}, sample rate {record.fs:g} Hz')
    print(f'Automatically detected beats: {len(peaks)}')
    print(f'Valid detected RR intervals: {predicted.kept_intervals} / {predicted.total_intervals}'
          f' ({(1-predicted.removed_fraction)*100:.2f}%)')
    print(f'Valid reference RR intervals: {reference.kept_intervals} / {reference.total_intervals}'
          f' ({(1-reference.removed_fraction)*100:.2f}%)')

    fig, ax = plt.subplots(figsize=(11.5, 4.4))
    for curve, label, color, alpha in [(reference, 'Reference-annotation RR', 'tab:orange', .8),
                                       (predicted, 'Detected-peak RR', 'tab:blue', .75)]:
        sel = (curve.time_s >= start) & (curve.time_s < start + duration)
        ax.plot(curve.time_s[sel], curve.rr_s[sel], '.', ms=3,
                color=color, alpha=alpha, label=label)
    if record.apnea_samples.size:
        for minute in np.arange(int(np.floor(start/60)),
                                int(np.ceil((start+duration)/60))):
            t = minute*60
            if apnea_status(record, np.array([t+1]))[0] == 8:
                ax.axvspan(max(t, start), min(t+60, start+duration),
                           alpha=.12, color='tab:blue')
    ax.set(xlim=(start, start+duration), xlabel='Time (s)',
           ylabel='R-R interval (s)',
           title=f'{record_name}: cleaned R-R series (shading: apnea-labelled minutes)')
    ax.legend(fontsize=9)
    ax.grid(alpha=.20)
    save_figure(fig, output_fig / f'fig_rr_tachogram_{record_name}')

    validation = interpolation_holdout(predicted.time_s, predicted.rr_s,
                                       t_start=start, duration_s=duration,
                                       stride=holdout_stride)
    val_rows = [{'record':record_name, 'method':label,
                 'n_holdout':validation['n_holdout'],
                 'rmse_s':value['rmse_s'], 'mae_s':value['mae_s']}
                for label, value in validation.items() if label != 'n_holdout']
    write_csv(output_res / 'rr_interpolation_validation.csv', val_rows)
    for row in val_rows:
        print(f"Interpolation holdout ({row['method']}): RMSE={row['rmse_s']:.5f}s, "
              f"MAE={row['mae_s']:.5f}s, n={row['n_holdout']}")
    fig, ax = plt.subplots(figsize=(7.0, 4))
    ax.bar([r['method'] for r in val_rows],
           [1000*r['rmse_s'] for r in val_rows])
    ax.set(ylabel='Held-out RR reconstruction RMSE (ms)',
           title=f'{record_name}: interpolation compared with mean baseline')
    ax.grid(axis='y', alpha=.2)
    save_figure(fig, output_fig / f'fig_interpolation_validation_{record_name}')

    spectra = []
    observed = spectral_comparison(predicted.time_s, predicted.rr_s,
                                  t_start=start, duration_s=duration)
    spectra.append({'record':record_name, 'source':'detected_RR',
                    'window_start_s':start, 'window_duration_s':duration,
                    'welch_bpm':60*observed['welch_peak_hz'],
                    'lomb_bpm':60*observed['lomb_peak_hz'],
                    'difference_bpm':observed['difference_bpm'],
                    'grid_coverage':observed['coverage']})
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.plot(observed['welch_f']*60, observed['welch_power_norm'],
            label='Welch PSD after linear RR interpolation')
    ax.plot(observed['lomb_f']*60, observed['lomb_power_norm'],
            label='Lomb-Scargle on irregular RR timestamps')
    ax.set(xlim=(6, 24), xlabel='Candidate frequency (cycles/min)',
           ylabel='Each spectrum normalized to its own peak',
           title=f'{record_name}: Welch and Lomb-Scargle spectra')
    ax.legend(fontsize=8)
    ax.grid(alpha=.20)
    save_figure(fig, output_fig / f'fig_rr_spectra_{record_name}')
    print(f"Observed RR spectral peaks: Welch={spectra[-1]['welch_bpm']:.2f} bpm, "
          f"Lomb={spectra[-1]['lomb_bpm']:.2f} bpm "
          '(candidate periodicities only)')

    synth_rows = []
    fig, ax = plt.subplots(figsize=(8, 4.2))
    for freq in (.15, .22, .32):
        beats = simulated_beats(respiration_hz=freq)
        series = rr_from_peaks(np.rint(beats*1000).astype(np.int64), 1000.)
        estimate = spectral_comparison(series.time_s, series.rr_s,
                                       t_start=10., duration_s=180.)
        synth_rows.append({'known_bpm':60*freq,
                           'welch_bpm':60*estimate['welch_peak_hz'],
                           'lomb_bpm':60*estimate['lomb_peak_hz'],
                           'welch_absolute_error_bpm':60*abs(estimate['welch_peak_hz']-freq),
                           'lomb_absolute_error_bpm':60*abs(estimate['lomb_peak_hz']-freq)})
        ax.plot(estimate['lomb_f']*60, estimate['lomb_power_norm'],
                label=f'Known {60*freq:.1f} bpm; Lomb peak {60*estimate["lomb_peak_hz"]:.1f}')
    ax.set(xlim=(6, 24), xlabel='Respiratory frequency (cycles/min)',
           ylabel='Normalized Lomb-Scargle power',
           title='Synthetic validation with known sinusoidal RR modulation')
    ax.legend(fontsize=8)
    ax.grid(alpha=.20)
    save_figure(fig, output_fig / 'fig_synthetic_frequency_validation')
    write_csv(output_res / 'rr_synthetic_frequency_validation.csv', synth_rows)
    for row in synth_rows:
        print(f"Synthetic {row['known_bpm']:.1f} bpm -> "
              f"Welch {row['welch_bpm']:.2f}, Lomb {row['lomb_bpm']:.2f} bpm")
    if spectra:
        write_csv(output_res / 'rr_candidate_spectra.csv', spectra)
    print('Step 3 files saved under figures/ and results/.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-zip', type=Path, default=Path('data.zip'))
    parser.add_argument('--record', default='a01')
    parser.add_argument('--start', type=float, default=660.)
    parser.add_argument('--duration', type=float, default=180.)
    parser.add_argument('--holdout-stride', type=int, default=7)
    parser.add_argument('--output-dir', type=Path, default=Path('.'))
    args = parser.parse_args()
    main(args.data_zip, args.record, args.start, args.duration, args.output_dir, args.holdout_stride)
