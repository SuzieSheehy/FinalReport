"""Stage 1: generate an observed ECG/QRS/apnea plot from data.zip.

Usage:
    python run_step1.py --data-zip data.zip --record a01 --start 774 --end 786
"""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from src.ecg_io import load_record, apnea_status


def make_annotated_figure(data_zip: Path, record: str, start: float, end: float,
                          output_dir: Path) -> dict:
    """Plot ECG samples, reference QRS locations and labelled apnea intervals.

    Returns simple summary statistics used in the report and tests.
    """
    if not (0 <= start < end):
        raise ValueError('Expected 0 <= start < end')
    ecg = load_record(data_zip, record)
    if end > ecg.ecg_mv.size / ecg.fs:
        raise ValueError('Requested window exceeds record duration')
    i0, i1 = int(start * ecg.fs), int(end * ecg.fs)
    t = np.arange(i0, i1) / ecg.fs
    sig = ecg.ecg_mv[i0:i1]
    qrs_idx = ecg.qrs_samples[(ecg.qrs_samples >= i0) & (ecg.qrs_samples < i1)]

    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(t, sig, lw=1.0, color='#16395d', label='ECG waveform')
    for i, p in enumerate(qrs_idx):
        ax.axvline(p / ecg.fs, lw=0.7, alpha=0.7, color='#c24b35',
                   label='Reference QRS annotation' if i == 0 else None)
    # A (.apn code 8) means apnea-labelled minute, N (code 1) means normal.
    if ecg.apnea_samples.size:
        for idx, a in enumerate(ecg.apnea_samples):
            if ecg.apnea_labels[idx] != 8:
                continue
            seg_start = a / ecg.fs
            if idx+1 < len(ecg.apnea_samples):
                seg_end = ecg.apnea_samples[idx+1] / ecg.fs
            else:
                seg_end = len(ecg.ecg_mv) / ecg.fs
            lo, hi = max(start, seg_start), min(end, seg_end)
            if lo < hi:
                ax.axvspan(lo, hi, color='#d3e3ef', alpha=0.8,
                           label='Apnea-labelled minute' if not any(p.get_label() == 'Apnea-labelled minute' for p in ax.patches[:-1]) else None)
    ax.set_xlim(start, end)
    ax.set_title(f'Record {record}: ECG, QRS annotations and apnea labels')
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('ECG amplitude (mV)')
    ax.legend(loc='upper right', fontsize=9)
    ax.grid(alpha=0.2)
    fig.tight_layout()
    output_dir.mkdir(exist_ok=True, parents=True)
    stem = f'fig_ecg_annotations_{record}'
    fig.savefig(output_dir / f'{stem}.pdf')
    fig.savefig(output_dir / f'{stem}.png', dpi=170)
    plt.close(fig)
    return {
        'record': record,
        'sampling_rate_hz': ecg.fs,
        'duration_hours': len(ecg.ecg_mv) / ecg.fs / 3600,
        'n_qrs_valid': len(ecg.qrs_samples),
        'n_apnea_minutes': int(np.sum(ecg.apnea_labels == 8)),
        'n_normal_minutes': int(np.sum(ecg.apnea_labels == 1)),
        'n_qrs_in_plot': len(qrs_idx),
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-zip', type=Path, default=Path('data.zip'))
    parser.add_argument('--record', default='a01')
    parser.add_argument('--start', type=float, default=774)
    parser.add_argument('--end', type=float, default=786)
    parser.add_argument('--output-dir', type=Path, default=Path('figures'))
    args = parser.parse_args()
    summary = make_annotated_figure(args.data_zip, args.record, args.start, args.end, args.output_dir)
    for k, v in summary.items():
        print(f'{k}: {v}')
    print(f'Plots saved in {args.output_dir.resolve()}')
