"""Owned-output cleanup and explicit stage status for repeatable script runs.

Only the listed generated files are removed; input data and unrelated files
are never globbed for deletion. Use a separate --output-dir to keep old runs.
"""
from __future__ import annotations

from contextlib import contextmanager
import csv
from datetime import datetime, timezone
import json
from pathlib import Path


STAGE_ARTIFACTS = {
    'step1': [f'figures/fig_ecg_annotations_*.{ext}' for ext in ('png', 'pdf')],
    'step2': ['results/qrs_detection_metrics.csv', 'tables/qrs_performance.tex',
              'tables/timing_offsets.tex'] +
             [f'figures/{name}.{ext}' for name in
              ('fig_r_peak_detection_a01', 'fig_qrs_f1_comparison')
              for ext in ('png', 'pdf')],
    'step3': ['results/rr_interpolation_validation.csv',
              'results/rr_synthetic_frequency_validation.csv',
              'results/rr_candidate_spectra.csv',
              'tables/interpolation.tex', 'tables/synthetic.tex'] +
             [f'figures/{name}.{ext}' for name in
              ('fig_rr_tachogram_*', 'fig_interpolation_validation_*',
               'fig_rr_spectra_*', 'fig_synthetic_frequency_validation')
              for ext in ('png', 'pdf')],
    'step4': ['results/rr_window_metrics.csv', 'results/rr_window_summary.csv',
              'results/rr_skipped_windows.csv', 'tables/window_summary.tex',
              'tables/consistency.tex', 'tables/rejected_windows.tex'] +
             [f'figures/{name}.{ext}' for name in
              ('fig_candidate_frequency_by_label', 'fig_method_sensitivity',
               'fig_rr_variability_by_label') for ext in ('png', 'pdf')],
}


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(payload, indent=2, default=str) + '\n',
                         encoding='utf-8')
    temporary.replace(path)


def clean_outputs(root: Path, patterns: list[str]) -> None:
    for pattern in patterns:
        for path in root.glob(pattern):
            if path.is_file():
                path.unlink()


def write_csv(path: Path, rows: list[dict], *, fieldnames=None) -> None:
    """Write a fresh CSV, including a fixed header when no rows were produced."""
    if fieldnames is None:
        if not rows:
            raise ValueError('Empty CSV output requires explicit fieldnames')
        fieldnames = list(rows[0])
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


@contextmanager
def stage_run(root: Path, stage: str, parameters: dict):
    """Invalidate previous outputs first; preserve the exception on failure."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    clean_outputs(root, STAGE_ARTIFACTS[stage])
    overall = root/'run_status.json'
    if overall.exists():
        previous = json.loads(overall.read_text(encoding='utf-8'))
        if previous.get('status') == 'success':
            previous.update(status='invalidated',
                            reason=f'{stage} rerun; regenerate dependent tables',
                            updated_at=timestamp())
            write_json(overall, previous)
    metadata = {'stage': stage, 'status': 'running', 'started_at': timestamp(),
                'parameters': parameters}
    path = root/'results'/f'{stage}_metadata.json'
    write_json(path, metadata)
    try:
        yield metadata
    except BaseException as exc:
        metadata.update(status='failed', finished_at=timestamp(),
                        error=f'{type(exc).__name__}: {exc}')
        write_json(path, metadata)
        raise
    else:
        metadata.update(status='success', finished_at=timestamp())
        metadata['artifacts'] = sorted({str(p.relative_to(root))
            for pattern in STAGE_ARTIFACTS[stage]
            for p in root.glob(pattern) if p.is_file()})
        write_json(path, metadata)
