"""Adaptive ECG R-peak detection and quantitative comparison to QRS labels.

Pipeline:
  (1) Butterworth band-pass (5–20 Hz) suppresses slow drift and T waves.
  (2) Absolute filtered amplitude handles positive- and negative-polarity ECGs.
  (3) Quantile/median-based local adaptive thresholds allow gain changes over time.
  (4) Peak prominence plus a refractory period discourages repeated detections.
  (5) Per-minute processing with one-second context limits memory usage.

A reference QRS annotation identifies a QRS complex, not necessarily its
highest-amplitude R sample; comparison therefore uses a defined tolerance.
No WFDB annotations are used to locate peaks; they enter evaluation only.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.signal import butter, find_peaks, sosfiltfilt


@dataclass(frozen=True)
class PeakMetrics:
    true_positive: int
    false_positive: int
    false_negative: int
    precision: float
    recall: float
    f1_score: float
    median_time_offset_ms: float
    p95_absolute_time_offset_ms: float


def detect_r_peaks(
    ecg_mv: np.ndarray,
    fs: float,
    *,
    lowcut_hz: float = 5.0,
    highcut_hz: float = 20.0,
    threshold_fraction: float = 0.40,
    minimum_separation_seconds: float = 0.35,
    block_seconds: float = 60.0,
) -> np.ndarray:
    """Return automatically detected R-peak sample positions.

    Parameters
    ----------
    ecg_mv : 1-D ndarray
        ECG signal in millivolts, without access to reference QRS locations.
    fs : float
        Samples per second (Hz).
    lowcut_hz, highcut_hz : float
        Band-pass limits; require 0 < lowcut < highcut < fs/2.
    threshold_fraction : float
        Fraction of local 99th percentile of |bandpassed ECG| used as peak
        height, bounded below by four times the median amplitude.
    minimum_separation_seconds : float
        Refractory period used to separate candidate beats.
    block_seconds : float
        Local adaptation block length. Blocks overlap by one second for
        filtering, but only detections in the central block are retained.

    Returns
    -------
    np.ndarray (int64)
        Ascending zero-based indices of candidate R peaks.
    """
    x = np.asarray(ecg_mv, dtype=np.float64)
    if x.ndim != 1 or len(x) == 0 or not np.all(np.isfinite(x)):
        raise ValueError('ecg_mv must be a non-empty finite 1-D array')
    if not (0 < lowcut_hz < highcut_hz < fs / 2):
        raise ValueError('Band-pass limits must fall below the Nyquist frequency')
    if not (0 < threshold_fraction <= 1):
        raise ValueError('threshold_fraction must be in (0,1]')
    min_samples = max(1, int(round(minimum_separation_seconds * fs)))
    block_samples = max(20, int(round(block_seconds * fs)))
    halo = max(int(round(fs)), 4 * min_samples)
    sos = butter(3, [lowcut_hz, highcut_hz], btype='bandpass', fs=fs, output='sos')

    detected: list[tuple[int, float]] = []
    for block_start in range(0, len(x), block_samples):
        block_end = min(block_start + block_samples, len(x))
        lo = max(0, block_start - halo)
        hi = min(len(x), block_end + halo)
        block = x[lo:hi]
        if len(block) < 20:
            continue
        filtered = sosfiltfilt(sos, block)
        strength = np.abs(filtered)
        height = max(
            threshold_fraction * float(np.quantile(strength, 0.99)),
            4.0 * float(np.median(strength)),
        )
        candidates, _ = find_peaks(
            strength,
            height=height,
            distance=min_samples,
            prominence=0.30 * height,
        )
        positions = candidates + lo
        keep = (positions >= block_start) & (positions < block_end)
        detected.extend(
            (int(p), float(strength[c]))
            for p, c in zip(positions[keep], candidates[keep])
        )

    # Handle adjacent block boundaries: retain the stronger of candidates
    # closer together than one refractory period.
    deduped: list[tuple[int, float]] = []
    for item in detected:
        if deduped and item[0] - deduped[-1][0] < min_samples:
            if item[1] > deduped[-1][1]:
                deduped[-1] = item
        else:
            deduped.append(item)
    return np.array([p for p, _ in deduped], dtype=np.int64)


def evaluate_r_peaks(
    detected_samples: np.ndarray,
    reference_samples: np.ndarray,
    fs: float,
    *,
    tolerance_seconds: float = 0.12,
) -> PeakMetrics:
    """One-to-one ordered matching within tolerance, independent of beat count.

    Each detection and reference event may be matched at most once. A match
    within tolerance is a true positive; unmatched detections are false
    positives, and unmatched annotations are false negatives. Differences
    between the selected peak and QRS annotation are not automatically errors
    in physiological peak timing.
    """
    det = np.asarray(detected_samples, dtype=np.int64)
    ref = np.asarray(reference_samples, dtype=np.int64)
    if fs <= 0 or tolerance_seconds < 0:
        raise ValueError('fs must be positive and tolerance non-negative')
    if np.any(np.diff(det) <= 0) or np.any(np.diff(ref) <= 0):
        raise ValueError('Inputs must contain strictly increasing sample indices')
    tolerance = int(round(tolerance_seconds * fs))
    i = j = 0
    offsets: list[int] = []
    while i < len(det) and j < len(ref):
        d = int(det[i]) - int(ref[j])
        if abs(d) <= tolerance:
            offsets.append(d)
            i += 1
            j += 1
        elif d < 0:
            i += 1
        else:
            j += 1
    tp = len(offsets)
    fp = len(det) - tp
    fn = len(ref) - tp
    precision = tp / len(det) if len(det) else 0.0
    recall = tp / len(ref) if len(ref) else 0.0
    f1 = 2 * tp / (2 * tp + fp + fn) if (2 * tp + fp + fn) else 0.0
    offsets_ms = np.asarray(offsets, dtype=float) / fs * 1000.0
    return PeakMetrics(
        tp, fp, fn, precision, recall, f1,
        float(np.median(offsets_ms)) if tp else float('nan'),
        float(np.percentile(np.abs(offsets_ms), 95)) if tp else float('nan'),
    )
