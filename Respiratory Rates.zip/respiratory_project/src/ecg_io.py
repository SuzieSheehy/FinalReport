"""Read PhysioNet Apnea-ECG files directly from the supplied data.zip.

This project dataset uses one-channel WFDB format-16 ECG signals.
The annotation decoder implements the MIT/WFDB two-byte format including
SKIP/NUM/SUB/CHN/AUX controls (WFDB Applications Guide, annot(5)).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import zipfile
import numpy as np


@dataclass(frozen=True)
class ECGRecord:
    name: str
    fs: float
    ecg_mv: np.ndarray
    qrs_samples: np.ndarray
    apnea_samples: np.ndarray
    apnea_labels: np.ndarray


def parse_annotations(payload: bytes) -> tuple[np.ndarray, np.ndarray]:
    """Decode binary WFDB annotation stream to absolute sample indices and codes.

    Parameters
    ----------
    payload : bytes
        Data from an annotation file such as .qrs or .apn.

    Returns
    -------
    samples : int64 array
        Absolute zero-based sample positions.
    codes : int16 array
        WFDB annotation codes: 1=N (normal), 8=A (apnea) for .apn;
        1=N for normal QRS beats in .qrs. These labels have different
        meanings according to the file extension, not the same event type.
    """
    sample = 0
    pos = 0
    samples, codes = [], []
    while pos + 1 < len(payload):
        b0, b1 = payload[pos], payload[pos + 1]
        pos += 2
        code = b1 >> 2
        dt = ((b1 & 3) << 8) | b0
        if code == 0 and dt == 0:
            break
        if code == 59:  # SKIP: 32-bit, high 16-bit word first, each word little-endian.
            if pos + 4 > len(payload):
                raise ValueError('Truncated WFDB SKIP annotation')
            high = int.from_bytes(payload[pos:pos + 2], 'little')
            low = int.from_bytes(payload[pos + 2:pos + 4], 'little')
            skip = (high << 16) | low
            if skip >= 2**31:
                skip -= 2**32
            sample += skip
            pos += 4
        elif code == 63:  # AUX: text, padded to even byte boundary.
            pos += dt + dt % 2
            if pos > len(payload):
                raise ValueError('Truncated WFDB AUX annotation')
        elif code in (60, 61, 62):  # NUM / SUB / CHN: metadata, not events.
            continue
        elif code > 0:
            sample += dt
            samples.append(sample)
            codes.append(code)
        else:
            sample += dt
    return np.asarray(samples, dtype=np.int64), np.asarray(codes, dtype=np.int16)


def load_record(data_zip: str | Path, record_name: str = 'a01') -> ECGRecord:
    """Load a record's ECG in mV and QRS/apnea reference annotations.

    Uses physical signal formula (digital - baseline) / gain (mV).
    Only one-channel format 16 is supported, matching the supplied archive.
    """
    if not re.fullmatch(r'[abcx]\d{2}', record_name):
        raise ValueError('Record name must look like a01 or x13')
    with zipfile.ZipFile(data_zip) as z:
        prefix = 'data/' + record_name
        header = z.read(prefix + '.hea').decode('ascii').strip().splitlines()
        first = header[0].split()
        signal = header[1].split()
        if int(first[1]) != 1 or int(signal[1]) != 16:
            raise ValueError('This loader supports one-channel WFDB format-16 records only')
        fs = float(first[2])
        expected_size = int(first[3])
        # Gain can be specified as ADCunits/mV, or include a suffix in other datasets.
        gain = float(signal[2].split('/')[0])
        baseline = int(signal[4])
        raw = np.frombuffer(z.read(prefix + '.dat'), dtype='<i2')
        if len(raw) != expected_size:
            raise ValueError(f'Length mismatch for {record_name}: {len(raw)} != {expected_size}')
        ecg_mv = (raw.astype(np.float64) - baseline) / gain
        qrs_all, qrs_codes = parse_annotations(z.read(prefix + '.qrs'))
        # Event code 16 marks artifact, not a valid R peak.
        qrs = qrs_all[qrs_codes == 1]
        apnea, labels = (np.array([], np.int64), np.array([], np.int16))
        if prefix + '.apn' in z.namelist():
            apnea, labels = parse_annotations(z.read(prefix + '.apn'))
    if not np.all(np.diff(qrs) > 0):
        raise ValueError(f'QRS annotations are not strictly increasing for {record_name}')
    return ECGRecord(record_name, fs, ecg_mv, qrs, apnea, labels)


def apnea_status(record: ECGRecord, t_seconds: np.ndarray) -> np.ndarray:
    """Return apnea label code for each time sample (0 if no annotations).

    Each apnea annotation labels the *subsequent* minute, so a label applies
    until the next annotation or the end of the recording.
    """
    times = np.asarray(t_seconds, dtype=float)
    if record.apnea_samples.size == 0:
        return np.zeros(times.shape, dtype=np.int16)
    idx = np.searchsorted(record.apnea_samples / record.fs, times, side='right') - 1
    out = np.zeros(times.shape, dtype=np.int16)
    valid = (idx >= 0) & (times < len(record.ecg_mv) / record.fs)
    out[valid] = record.apnea_labels[idx[valid]]
    return out
