"""Predefined non-overlapping windows and label-aware descriptive comparisons.

The per-minute apnea labels describe sleep-apnea status, NOT true respiration
frequency. Window sampling is stratified so both classes may be inspected; it
must not be used to estimate apnea prevalence or population diagnostic accuracy.
"""
from __future__ import annotations

import numpy as np
from src.ecg_io import ECGRecord, apnea_status


def window_label(record: ECGRecord, start_s: float, duration_s: float = 180.) -> str:
    """Only call windows wholly normal or wholly apnea; others are 'mixed'.

    Assumes start and duration are integral minutes. Annotation applied at the
    centre of each minute. A missing annotation returns 'unlabelled'.
    """
    if duration_s <= 0 or start_s < 0 or duration_s % 60 != 0 or start_s % 60 != 0:
        raise ValueError('start and duration must align to full 60-s minutes')
    centres = start_s + 30. + 60.*np.arange(int(duration_s/60))
    codes = apnea_status(record, centres)
    if np.any(codes == 0):
        return 'unlabelled'
    if np.all(codes == 1):
        return 'normal'
    if np.all(codes == 8):
        return 'apnea'
    return 'mixed'


def evenly_spaced_subset(items: list[float], count: int) -> list[float]:
    """Select at most count items, deterministically across their time span."""
    if count <= 0:
        raise ValueError('count must be positive')
    if len(items) <= count:
        return list(items)
    idx = np.rint(np.linspace(0, len(items)-1, count)).astype(int)
    return [items[int(i)] for i in idx]


def select_stratified_windows(record: ECGRecord, *, duration_s: float = 180.,
                              max_per_label: int = 4) -> list[tuple[float, str]]:
    """Select separated windows from across the whole record by label.

    Sampling intentionally balances labels within each record where feasible.
    This is a visualization/robustness design, not a prevalence estimator.
    'mixed' and 'unlabelled' windows are excluded from class comparisons.
    """
    if duration_s % 60 != 0 or duration_s <= 0:
        raise ValueError('duration_s must be a positive multiple of 60')
    available = len(record.ecg_mv) / record.fs
    starts = np.arange(0., available-duration_s+1e-9, duration_s)
    groups = {'normal': [], 'apnea': []}
    for s in starts:
        label = window_label(record, float(s), duration_s)
        if label in groups:
            groups[label].append(float(s))
    selected = [(s, label)
                for label, times in groups.items()
                for s in evenly_spaced_subset(times, max_per_label)]
    return sorted(selected)


def summarize_rows(rows: list[dict]) -> list[dict]:
    """Produce per-record and label medians; descriptive only."""
    out = []
    for record in sorted({r['record'] for r in rows}):
        for label in ('normal', 'apnea'):
            part = [r for r in rows if r['record'] == record and r['label'] == label]
            if not part:
                continue
            metrics = ['sdnn_ms', 'welch_bpm', 'lomb_bpm',
                       'method_difference_bpm', 'interpolation_difference_bpm',
                       'auto_reference_difference_bpm']
            summary = {'record': record, 'label': label, 'n_windows': len(part)}
            summary.update({f'median_{m}': float(np.median([r[m] for r in part]))
                            for m in metrics})
            out.append(summary)
    return out
