"""R--R interval construction, gap-aware resampling and spectral cross-check.

R--R intervals are irregularly timed (beat-midpoint timestamps). A 4-Hz
interpolated grid is an *analysis grid*, not additional acquired information.
We compare interpolated Welch spectra against Lomb--Scargle spectra evaluated
on the original irregular timestamps. Physiological conclusions require
independent respiratory-rate ground truth, which apnea labels do not provide.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.ndimage import median_filter
from scipy.interpolate import PchipInterpolator
from scipy.signal import welch, lombscargle, detrend


@dataclass(frozen=True)
class RRSeries:
    time_s: np.ndarray
    rr_s: np.ndarray
    total_intervals: int
    kept_intervals: int

    @property
    def removed_fraction(self) -> float:
        return 1.0 - self.kept_intervals / self.total_intervals if self.total_intervals else 0.0


def rr_from_peaks(peaks: np.ndarray, fs: float, *, min_rr_s: float = .35,
                  max_rr_s: float = 2.0, local_deviation: float = .40,
                  local_window: int = 11) -> RRSeries:
    """Create a cleaned tachogram from ascending R-peak *sample positions*.

    Each interval is attached to the midpoint of its two beats. An interval
    outside the plausible 0.35--2 s range or >40% from the local median is
    flagged, not treated as a valid respiratory fluctuation. These heuristic
    thresholds are exposed so that sensitivity can be assessed; they are not
    clinical criteria. The original detected peak sequence is not modified.
    """
    p = np.asarray(peaks, dtype=np.int64)
    if fs <= 0 or p.ndim != 1 or len(p) < 3 or np.any(np.diff(p) <= 0):
        raise ValueError('Need >=3 strictly increasing R peaks and positive fs')
    if not (0 < min_rr_s < max_rr_s and 0 < local_deviation < 1):
        raise ValueError('Invalid RR cleaning parameter')
    if local_window < 3 or local_window % 2 != 1:
        raise ValueError('local_window must be odd and >=3')
    rr = np.diff(p).astype(float) / fs
    mid = (p[:-1].astype(float) + p[1:].astype(float)) / (2*fs)
    med = median_filter(rr, size=local_window, mode='nearest')
    valid = ((rr >= min_rr_s) & (rr <= max_rr_s)
             & (np.abs(rr - med) <= local_deviation * med))
    return RRSeries(mid[valid], rr[valid], len(rr), int(valid.sum()))


def resample_rr(time_s: np.ndarray, rr_s: np.ndarray, t_start: float,
                t_end: float, *, fs_grid: float = 4.0, max_gap_s: float = 3.0,
                method: str = 'linear') -> tuple[np.ndarray, np.ndarray]:
    """Resample irregular RR points to a regular grid; mark large gaps as NaN.

    Never extrapolate past the first/last genuine RR observation. A gap
    strictly between successive observations >max_gap_s remains NaN;
    genuine observations at both endpoints are retained.
    For reproducible spectral analysis, windows with NaNs are omitted.
    """
    x = np.asarray(time_s, dtype=float)
    y = np.asarray(rr_s, dtype=float)
    if x.ndim != 1 or y.shape != x.shape or len(x) < 2 or np.any(np.diff(x) <= 0):
        raise ValueError('Need >=2 strictly increasing times and matching RR values')
    if not (np.all(np.isfinite(x)) and np.all(np.isfinite(y))):
        raise ValueError('Inputs must be finite')
    if not (t_end > t_start and fs_grid > 0 and max_gap_s > 0):
        raise ValueError('Invalid grid or gap settings')
    if method not in ('linear', 'pchip'):
        raise ValueError('method must be linear or pchip')
    grid = np.arange(t_start, t_end, 1 / fs_grid)
    vals = (np.interp(grid, x, y) if method == 'linear'
            else PchipInterpolator(x, y, extrapolate=False)(grid))
    vals = np.asarray(vals, dtype=float)
    vals[(grid < x[0]) | (grid > x[-1])] = np.nan
    left = np.searchsorted(x, grid, side='right') - 1
    interior = (left >= 0) & (left < len(x) - 1)
    bad = np.zeros(len(grid), dtype=bool)
    bad[interior] = ((x[left[interior] + 1] - x[left[interior]] > max_gap_s)
                     & (grid[interior] > x[left[interior]]))
    vals[bad] = np.nan
    return grid, vals


def spectral_comparison(time_s: np.ndarray, rr_s: np.ndarray, *,
                        t_start: float, duration_s: float = 180.,
                        fs_grid: float = 4., freq_min_hz: float = .10,
                        freq_max_hz: float = .40,
                        method: str = 'linear') -> dict:
    """Compare Welch on resampled RR vs Lomb--Scargle on original timestamps.

    Both spectra are independently normalized to a maximum of 1 for display.
    Relative spectral heights between the two methods should NOT be compared.
    The selected bands are hypotheses, not ground-truth validation.
    Non-finite inputs and numerically negligible detrended variation raise
    ValueError. The roundoff guard is NOT a noise or peak-significance test;
    non-degenerate noise can still produce an unvalidated candidate peak.
    """
    x = np.asarray(time_s, dtype=float)
    y = np.asarray(rr_s, dtype=float)
    if x.ndim != 1 or y.shape != x.shape or np.any(np.diff(x) <= 0):
        raise ValueError('Need strictly increasing times and matching RR values')
    if not (np.all(np.isfinite(x)) and np.all(np.isfinite(y))):
        raise ValueError('Inputs must be finite')
    settings = [t_start, duration_s, fs_grid, freq_min_hz, freq_max_hz]
    if not (np.all(np.isfinite(settings)) and duration_s > 0 and
            0 < freq_min_hz < freq_max_hz <= fs_grid/2):
        raise ValueError('Invalid window, sampling frequency or frequency band')
    mask = (x >= t_start) & (x < t_start + duration_s)
    ti, yi = x[mask], y[mask]
    if len(ti) < 40:
        raise ValueError('Insufficient valid R-R data for selected window')
    relative = ti - ti[0]
    yi_residual = yi - np.polyval(np.polyfit(relative, yi, 1), relative)
    # A numerical floor in RR units, not a physiological modulation threshold.
    floor = 100*np.finfo(float).eps*max(1., float(np.max(np.abs(yi))))
    if not np.all(np.isfinite(yi_residual)):
        raise ValueError('Non-finite detrended R-R values')
    if np.max(np.abs(yi_residual)) <= floor:
        raise ValueError('Numerically negligible detrended R-R variation; no candidate')
    grid, vals = resample_rr(ti, yi, t_start, t_start + duration_s,
                             fs_grid=fs_grid, method=method)
    coverage = float(np.isfinite(vals).mean())
    if coverage < .95:
        raise ValueError(f'Grid coverage too low ({coverage:.1%}); skip this window')
    # Fill only boundary NaNs induced by missing interval midpoints; never bridge
    # a large internal gap (those would reduce coverage and may require rejection).
    if np.any(~np.isfinite(vals)):
        good = np.isfinite(vals)
        internal_gaps = np.where(~good)[0]
        if np.any((internal_gaps > np.flatnonzero(good)[0]) &
                  (internal_gaps < np.flatnonzero(good)[-1])):
            raise ValueError('Internal gaps present; skip window rather than invent data')
        vals = np.interp(grid, grid[good], vals[good])
    nperseg = min(512, len(vals))
    starts = range(0, len(vals)-nperseg+1, nperseg-nperseg//2)
    if all(np.max(np.abs(detrend(vals[s:s+nperseg], type='linear'))) <= floor
           for s in starts):
        raise ValueError('Numerically negligible variation in Welch segments; no candidate')
    welch_f, welch_psd = welch(vals, fs=fs_grid,
                               nperseg=nperseg,
                               detrend='linear', noverlap=None)
    in_band = (welch_f >= freq_min_hz) & (welch_f <= freq_max_hz)
    if not np.any(in_band):
        raise ValueError('Frequency band not resolved')
    if not np.all(np.isfinite(welch_psd)) or np.max(welch_psd[in_band]) <= 0:
        raise ValueError('Welch spectrum has no finite positive band power')
    peak_w = float(welch_f[in_band][np.argmax(welch_psd[in_band])])
    freqs = np.linspace(freq_min_hz, freq_max_hz, 601)
    # Linear detrending above uses the irregular time axis, not sample indices.
    lomb_power = lombscargle(relative, yi_residual, 2*np.pi*freqs,
                             normalize=True)
    if not np.all(np.isfinite(lomb_power)) or np.max(lomb_power) <= 0:
        raise ValueError('Lomb-Scargle spectrum has no finite positive band power')
    peak_l = float(freqs[np.argmax(lomb_power)])
    wnorm = welch_psd / float(welch_psd[in_band].max())
    lnorm = lomb_power / float(lomb_power.max())
    return {'window_start_s': t_start, 'duration_s': duration_s,
            'n_irregular_points': len(ti), 'coverage': coverage,
            'welch_peak_hz': peak_w, 'lomb_peak_hz': peak_l,
            'difference_bpm': 60.0 * abs(peak_w - peak_l),
            'grid_t': grid, 'interpolated_rr': vals,
            'irregular_t': ti, 'irregular_rr': yi,
            'welch_f': welch_f, 'welch_power_norm': wnorm,
            'lomb_f': freqs, 'lomb_power_norm': lnorm}



def interpolation_holdout(time_s: np.ndarray, rr_s: np.ndarray, *,
                          t_start: float, duration_s: float = 180.,
                          stride: int = 7, max_gap_s: float = 3.0) -> dict:
    """Hold out every seventh RR observation, predict it and report errors.

    This measures how well interpolation reconstructs omitted *RR observations*,
    not the accuracy of respiration inference. Include a constant-mean baseline.
    For fair comparison, evaluate exactly the same held-out points.
    """
    t = np.asarray(time_s, dtype=float)
    y = np.asarray(rr_s, dtype=float)
    select = (t >= t_start) & (t < t_start + duration_s)
    t, y = t[select], y[select]
    if len(t) < 50 or stride < 3:
        raise ValueError('Need >=50 RR observations and stride >=3')
    heldout = (np.arange(len(t)) % stride == stride // 2)
    train_t, train_y = t[~heldout], y[~heldout]
    test_t, test_y = t[heldout], y[heldout]
    which = np.searchsorted(train_t, test_t, side='right') - 1
    usable = (which >= 0) & (which < len(train_t)-1)
    which = which[usable]
    ok = train_t[which + 1] - train_t[which] <= max_gap_s
    test_t, test_y = test_t[usable][ok], test_y[usable][ok]
    if len(test_t) < 10:
        raise ValueError('Not enough safely interpolable held-out points')
    linear = np.interp(test_t, train_t, train_y)
    pchip = PchipInterpolator(train_t, train_y)(test_t)
    constant = np.full_like(test_y, float(train_y.mean()))
    def metrics(predicted):
        delta = predicted - test_y
        return {'rmse_s': float(np.sqrt(np.mean(delta**2))),
                'mae_s': float(np.mean(np.abs(delta)))}
    return {'n_holdout': len(test_t),
            'constant': metrics(constant),
            'linear': metrics(linear),
            'pchip': metrics(pchip)}


def simulated_beats(*, duration_s: float = 240., base_rr_s: float = .82,
                    modulation_s: float = .07, respiration_hz: float = .22
                    ) -> np.ndarray:
    """Generate beat times with explicitly known sinusoidal RR modulation.

    This is a *synthetic validation*, not an ECG respiratory-rate ground truth.
    A sinusoid affects interval duration evaluated at the current beat time.
    """
    beats = [0.]
    while beats[-1] < duration_s:
        rr = base_rr_s + modulation_s * np.sin(2*np.pi*respiration_hz*beats[-1])
        beats.append(beats[-1] + rr)
    return np.asarray(beats)
