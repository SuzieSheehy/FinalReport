"""Small correctness and numerical validation tests, independent of dataset."""
import numpy as np
import pytest
from src.rr_analysis import rr_from_peaks, resample_rr, spectral_comparison, simulated_beats


def test_rr_midpoint_timing():
    out = rr_from_peaks(np.array([0, 100, 200, 300]), fs=100)
    assert out.total_intervals == out.kept_intervals == 3
    np.testing.assert_allclose(out.time_s, [0.5, 1.5, 2.5])
    np.testing.assert_allclose(out.rr_s, [1, 1, 1])


def test_rr_rejects_spurious_short_interval():
    # A false early detection, together with a normal set of beats.
    times = np.array([0, 100, 200, 300, 400, 410, 500, 600, 700])
    out = rr_from_peaks(times, fs=100)
    assert out.kept_intervals < out.total_intervals
    assert np.all(out.rr_s >= .35)


def test_resampling_gap_mask_and_no_extrapolation():
    t = np.array([0., 1., 2., 8., 9.])
    y = np.array([.8, .9, .8, .9, .8])
    grid, vals = resample_rr(t, y, -1., 11., fs_grid=1., max_gap_s=2.)
    assert np.isnan(vals[0]) and np.isnan(vals[-1])
    assert np.isnan(vals[np.where(grid == 4.)[0][0]])
    np.testing.assert_allclose(vals[np.where(grid == 1.)[0][0]], .9)


def test_interpolation_recovers_known_synthetic_signal():
    rng = np.random.default_rng(41)
    t = np.cumsum(rng.uniform(.75, 1.15, size=250))
    f0 = .2
    x = .85 + .07*np.sin(2*np.pi*f0*t)
    grid, vals = resample_rr(t, x, 5., 200., fs_grid=4.)
    ok = np.isfinite(vals)
    truth = .85 + .07*np.sin(2*np.pi*f0*grid[ok])
    assert np.sqrt(np.mean((truth-vals[ok])**2)) < .02


def test_synthetic_frequency_with_lomb_and_interpolation():
    fs = 1000
    beat_s = simulated_beats(respiration_hz=.22)
    series = rr_from_peaks(np.round(fs*beat_s).astype(int), fs)
    r = spectral_comparison(series.time_s, series.rr_s,
                            t_start=10., duration_s=180.)
    assert abs(r['lomb_peak_hz']-.22) < .015
    assert abs(r['welch_peak_hz']-.22) < .02
    assert r['coverage'] >= .95


def test_nonmonotone_rejected():
    with pytest.raises(ValueError):
        rr_from_peaks(np.array([0, 50, 40]), 100)


@pytest.mark.parametrize('method', ['linear', 'pchip'])
def test_long_gap_preserves_both_observed_endpoints(method):
    t = np.array([0., 1., 2., 8., 9.])
    y = np.array([.8, .9, .8, .9, .8])
    grid, values = resample_rr(t, y, -1., 11., fs_grid=1., method=method)
    np.testing.assert_allclose(values[np.isin(grid, t)], y)
    assert np.all(np.isnan(values[(grid > 2) & (grid < 8)]))
    assert np.all(np.isnan(values[(grid < 0) | (grid > 9)]))


@pytest.mark.parametrize('kind', ['constant', 'roundoff', 'linear'])
def test_spectra_reject_numerically_degenerate_modulation(kind):
    t = np.arange(.5, 240., 1.)
    y = np.ones_like(t)
    if kind == 'roundoff':
        y += 1e-15 * np.sin(2*np.pi*.2*t)
    elif kind == 'linear':
        y += .0001*t
    with pytest.raises(ValueError, match='[Nn]umerically negligible'):
        spectral_comparison(t, y, t_start=10.)


def test_welch_rejects_constant_used_segment_even_if_later_data_oscillate():
    t = np.arange(.5, 240., 1.)
    y = np.ones_like(t)
    y[t >= 150.] += .05*np.sin(2*np.pi*.2*t[t >= 150.])
    with pytest.raises(ValueError, match='Welch'):
        spectral_comparison(t, y, t_start=10.)


def test_small_resolved_off_grid_modulation_is_not_rejected_as_noise():
    # Numerical protection must not become an unvalidated amplitude threshold.
    t = np.arange(.5, 240., .9)
    y = 1. + 1e-8*np.sin(2*np.pi*.2173*t)
    result = spectral_comparison(t, y, t_start=10.)
    assert abs(result['lomb_peak_hz'] - .2173) <= .0005
    assert abs(result['welch_peak_hz'] - .2173) < .008


def test_nonfinite_timestamp_is_not_silently_removed_by_window_mask():
    t = np.arange(.5, 240., 1.)
    y = 1. + .05*np.sin(2*np.pi*.2*t)
    t[100] = np.nan
    with pytest.raises(ValueError, match='finite'):
        spectral_comparison(t, y, t_start=10.)
