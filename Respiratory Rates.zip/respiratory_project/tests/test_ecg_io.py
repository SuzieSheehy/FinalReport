"""Small decoder tests that do not require the large downloaded data.zip."""
import numpy as np
from src.ecg_io import parse_annotations


def test_simple_annotations():
    # Two normal events: 34, then 34+89.
    samples, code = parse_annotations(bytes.fromhex('22 04 59 04 00 00'))
    assert samples.tolist() == [34, 123]
    assert code.tolist() == [1, 1]


def test_skip_large_gap():
    # t=0 normal, 6000-sample SKIP, t=6000 normal.
    raw = bytes.fromhex('00 04 00 ec 00 00 70 17 00 04 00 00')
    samples, code = parse_annotations(raw)
    assert samples.tolist() == [0, 6000]
    assert code.tolist() == [1, 1]


def test_aux_and_special_metadata_ignored():
    # Ordinary event, AUX with three letters and one padding byte, new event.
    raw = bytes.fromhex('01 04 03 fc 41 42 43 00 02 04 00 00')
    samples, _ = parse_annotations(raw)
    assert samples.tolist() == [1, 3]
