"""Synthetic-data and event-matching tests; no patient data needed."""
import numpy as np
import pytest

from src.rpeaks import detect_r_peaks, evaluate_r_peaks


def _synthetic_ecg(*, inverted=False, seed=2026):
    fs = 100
    t = np.arange(0, 22, 1/fs)
    true_times = 1.0 + np.arange(20) * .96
    rng = np.random.default_rng(seed)
    signal = 0.02*rng.standard_normal(len(t)) + .06*np.sin(2*np.pi*.15*t)
    for beat in true_times:
        signal += (1.0 if not inverted else -1.0) * np.exp(-.5*((t-beat)/.023)**2)
    return signal, fs, (true_times*fs).astype(int)


@pytest.mark.parametrize('inverted', [False, True])
def test_synthetic_detection(inverted):
    signal, fs, reference = _synthetic_ecg(inverted=inverted)
    detected = detect_r_peaks(signal, fs)
    metrics = evaluate_r_peaks(detected, reference, fs, tolerance_seconds=.12)
    assert metrics.f1_score >= .95


def test_one_to_one_matching():
    det = np.array([100, 102, 200, 300])
    ref = np.array([101, 201, 400])
    result = evaluate_r_peaks(det, ref, 100, tolerance_seconds=.12)
    assert result.true_positive == 2
    assert result.false_positive == 2
    assert result.false_negative == 1


def test_invalid_filter_range():
    with pytest.raises(ValueError):
        detect_r_peaks(np.ones(1000), fs=100, highcut_hz=60)


@pytest.mark.parametrize('polarity', [1., -1.])
def test_beats_on_sixty_second_block_boundaries_are_not_lost_or_duplicated(polarity):
    fs = 100
    time = np.arange(0., 130., 1/fs)
    beat_times = np.arange(.8, 129., .8)  # Includes beats exactly at 60 and 120 s.
    ecg = .01*np.sin(2*np.pi*.17*time)
    for beat in beat_times:
        ecg += polarity*np.exp(-.5*((time-beat)/.023)**2)
    detected = detect_r_peaks(ecg, fs)
    for boundary in (6000, 12000):
        near = detected[np.abs(detected-boundary) <= 10]
        assert len(near) == 1
        assert abs(near[0]-boundary) <= 2
    score = evaluate_r_peaks(detected, np.rint(beat_times*fs).astype(int), fs)
    assert score.false_positive == score.false_negative == 0
