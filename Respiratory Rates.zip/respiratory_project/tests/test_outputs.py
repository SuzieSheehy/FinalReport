"""Regression tests for stale outputs, failures and parameter-aware captions."""
import argparse
import csv
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest

import make_report_tables as tables
import run_all
import run_step3
import run_step4
from src.ecg_io import ECGRecord
from src.rr_analysis import simulated_beats


def _record(constant=False):
    beats = (np.arange(0., 421.) if constant else
             simulated_beats(duration_s=420.))
    return ECGRecord('a01', 100., np.zeros(42200),
                     np.rint(beats*100).astype(int),
                     np.arange(0, 42000, 6000), np.ones(7, dtype=int))


def _csv(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def test_step3_failure_invalidates_old_spectrum_and_tables(tmp_path, monkeypatch):
    rec = _record(constant=True)
    monkeypatch.setattr(run_step3, 'load_record', lambda *a: rec)
    monkeypatch.setattr(run_step3, 'detect_r_peaks', lambda *a: rec.qrs_samples)
    stale = ['results/rr_candidate_spectra.csv',
             'figures/fig_rr_spectra_a01.png', 'figures/fig_rr_spectra_a01.pdf',
             'tables/interpolation.tex']
    for name in stale:
        path = tmp_path/name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text('old output')
    with pytest.raises(ValueError):
        run_step3.main(tmp_path/'data.zip', 'a01', 10., 180., tmp_path)
    assert all(not (tmp_path/name).exists() for name in stale)
    status = json.loads((tmp_path/'results/step3_metadata.json').read_text())
    assert status['status'] == 'failed'


@pytest.mark.parametrize('constant', [False, True])
def test_step4_rewrites_empty_outputs_and_records_rejections(tmp_path, monkeypatch, constant):
    rec = _record(constant=constant)
    monkeypatch.setattr(run_step4, 'load_record', lambda *a: rec)
    monkeypatch.setattr(run_step4, 'detect_r_peaks', lambda *a: rec.qrs_samples)
    old = tmp_path/'results/rr_skipped_windows.csv'
    _csv(old, [{'record': 'old', 'label': 'apnea', 'window_start_s': 0, 'reason': 'old'}])
    args = argparse.Namespace(output_dir=tmp_path, data_zip=tmp_path/'data.zip',
                              records=['a01'], duration_s=180., max_per_label=4)
    if constant:
        with pytest.raises(RuntimeError, match='All windows rejected'):
            run_step4.main(args)
    else:
        run_step4.main(args)
    with old.open() as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)
        assert reader.fieldnames == ['record', 'label', 'window_start_s', 'reason']
    assert len(rows) == (2 if constant else 0)
    assert all(r['record'] == 'a01' for r in rows)
    with (tmp_path/'results/rr_window_metrics.csv').open() as stream:
        reader = csv.DictReader(stream)
        metrics = list(reader)
        assert 'welch_bpm' in reader.fieldnames
    assert len(metrics) == (0 if constant else 2)


def test_captions_follow_record_window_stride_and_sample_count(tmp_path, monkeypatch):
    results, out = tmp_path/'results', tmp_path/'tables'
    monkeypatch.setattr(tables, 'RESULTS', results)
    monkeypatch.setattr(tables, 'TABLES', out)
    _csv(results/'rr_interpolation_validation.csv', [
        {'record': 'b01', 'method': method, 'n_holdout': 7, 'rmse_s': .02, 'mae_s': .01}
        for method in ['constant', 'linear', 'pchip']])
    (results/'step3_metadata.json').write_text(json.dumps({
        'status': 'success', 'parameters': {'record': 'b01', 'start_s': 90.,
        'duration_s': 180., 'holdout_stride': 5}}))
    tables.validation_table()
    tex = (out/'interpolation.tex').read_text()
    assert 'b01' in tex and '90--270' in tex
    assert 'stride 5' in tex and '7 held-out' in tex
    assert 'a01' not in tex and '28 evaluation' not in tex
    _csv(results/'rr_window_metrics.csv', [
        {'window_duration_s': 120., 'interpolation_difference_bpm': .2,
         'auto_reference_difference_bpm': .5, 'method_difference_bpm': 2.},
        {'window_duration_s': 120., 'interpolation_difference_bpm': 1.5,
         'auto_reference_difference_bpm': .3, 'method_difference_bpm': .4}])
    tables.consistency_table()
    tex = (out/'consistency.tex').read_text()
    assert '2 accepted 120-s windows' in tex
    assert '1 / 2' in tex and '2 / 2' in tex


def test_failed_stage_cannot_regenerate_tables_from_old_csv(tmp_path, monkeypatch):
    monkeypatch.setattr(tables, 'RESULTS', tmp_path)
    monkeypatch.setattr(tables, 'TABLES', tmp_path/'tables')
    _csv(tmp_path/'rr_window_metrics.csv', [
        {'interpolation_difference_bpm': 0, 'auto_reference_difference_bpm': 0,
         'method_difference_bpm': 0, 'window_duration_s': 180.}])
    (tmp_path/'step4_metadata.json').write_text(json.dumps({'status': 'failed'}))
    with pytest.raises(ValueError, match='step4'):
        tables.consistency_table()


def test_driver_failure_is_recorded_and_old_tables_invalidated(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path/'data.zip').write_bytes(b'placeholder for mocked external stages')
    (tmp_path/'tables').mkdir()
    (tmp_path/'tables/consistency.tex').write_text('old')
    (tmp_path/'tables/timing_offsets.tex').write_text('old')
    (tmp_path/'tables/rejected_windows.tex').write_text('old')
    (tmp_path/'tables/user_notes.txt').write_text('keep')
    monkeypatch.setattr(sys, 'argv', ['run_all.py', '--skip-tests'])
    def external_stage(command):
        if any(Path(value).name == 'run_step3.py' for value in command):
            raise subprocess.CalledProcessError(1, command)
    monkeypatch.setattr(run_all, 'run_checked', external_stage)
    with pytest.raises(subprocess.CalledProcessError):
        run_all.main()
    status = json.loads((tmp_path/'run_status.json').read_text())
    assert status['status'] == 'failed'
    assert status['current_stage'] == 'run_step3.py'
    assert not (tmp_path/'tables/consistency.tex').exists()
    assert not (tmp_path/'tables/timing_offsets.tex').exists()
    assert not (tmp_path/'tables/rejected_windows.tex').exists()
    assert (tmp_path/'tables/user_notes.txt').read_text() == 'keep'


def test_table_driver_generates_all_seven_tables_from_current_csvs(tmp_path, monkeypatch):
    results, output = tmp_path/'results', tmp_path/'tables'
    # Generated project outputs may have been cleared before tests run. Build
    # this small fixture independently so a clean default run needs no results.
    _csv(results/'qrs_detection_metrics.csv', [{
        'record': 'a01', 'TP': 8, 'FP': 1, 'FN': 2,
        'precision': 8/9, 'recall': .8, 'F1': 16/19,
        'median_offset_ms': -20, 'p95_abs_offset_ms': 90}])
    _csv(results/'rr_interpolation_validation.csv', [
        {'record': 'a01', 'method': method, 'n_holdout': 7,
         'rmse_s': rmse, 'mae_s': mae}
        for method, rmse, mae in [('constant', .08, .06),
                                  ('linear', .03, .02),
                                  ('pchip', .025, .018)]])
    _csv(results/'rr_synthetic_frequency_validation.csv', [{
        'known_bpm': 12., 'welch_bpm': 12.1875, 'lomb_bpm': 12.,
        'welch_absolute_error_bpm': .1875}])
    _csv(results/'rr_window_metrics.csv', [{
        'record': 'a01', 'label': 'normal', 'window_start_s': 0.,
        'window_duration_s': 120., 'interpolation_difference_bpm': .1,
        'auto_reference_difference_bpm': .2, 'method_difference_bpm': 1.4}])
    _csv(results/'rr_window_summary.csv', [{
        'record': 'a01', 'label': 'normal', 'n_windows': 1,
        'median_sdnn_ms': 50., 'median_welch_bpm': 12.,
        'median_lomb_bpm': 13.4}])
    _csv(results/'rr_skipped_windows.csv', [
        {'record': 'b05', 'label': 'normal', 'window_start_s': 7560.,
         'reason': 'Grid coverage too low (46.5%); skip this window'},
        {'record': 'b05', 'label': 'apnea', 'window_start_s': 19260.,
         'reason': 'Internal gaps present; skip window rather than invent data'},
        {'record': 'c01', 'label': 'normal', 'window_start_s': 28800.,
         'reason': 'Grid coverage too low (92.8%); skip this window'}])
    parameters = {
        'step2': {'matching_tolerance_s': .12},
        'step3': {'record': 'a01', 'start_s': 90., 'duration_s': 120.,
                  'holdout_stride': 5},
        'step4': {'duration_s': 120.}}
    for stage, settings in parameters.items():
        (results/f'{stage}_metadata.json').write_text(json.dumps({
            'status': 'success', 'parameters': settings}))
    monkeypatch.setattr(tables, 'RESULTS', results)
    monkeypatch.setattr(tables, 'TABLES', output)
    tables.main()
    assert {p.name for p in output.glob('*.tex')} == {
        'qrs_performance.tex', 'timing_offsets.tex', 'interpolation.tex',
        'synthetic.tex', 'consistency.tex', 'rejected_windows.tex',
        'window_summary.tex'}
    assert 'a01 & -20 & 90' in (output/'timing_offsets.tex').read_text()
    assert '7 held-out' in (output/'interpolation.tex').read_text()
    assert '1 accepted 120-s windows' in (output/'consistency.tex').read_text()
    rejected = (output/'rejected_windows.tex').read_text()
    assert '46.5\\%' in rejected and '92.8\\%' in rejected
    assert '19,260' in rejected and 'Unresolved internal gap' in rejected


def test_rejected_table_rewrites_empty_results_and_escapes_new_reasons(tmp_path, monkeypatch):
    results, output = tmp_path/'results', tmp_path/'tables'
    fields = ['record', 'label', 'window_start_s', 'reason']
    _csv(results/'rr_skipped_windows.csv', [], fields=fields)
    (results/'step4_metadata.json').write_text(json.dumps({
        'status': 'success', 'parameters': {'duration_s': 120.}}))
    output.mkdir()
    (output/'rejected_windows.tex').write_text('outdated rejection')
    monkeypatch.setattr(tables, 'RESULTS', results)
    monkeypatch.setattr(tables, 'TABLES', output)
    tables.rejected_windows_table()
    tex = (output/'rejected_windows.tex').read_text()
    assert 'outdated rejection' not in tex and '120-s windows' in tex
    _csv(results/'rr_skipped_windows.csv', [{
        'record': 'x01', 'label': 'normal', 'window_start_s': 120,
        'reason': 'sensor_gap & loss_50% #1'}, {
        'record': 'x02', 'label': 'apnea', 'window_start_s': 240,
        'reason': 'Grid coverage too low (87.5%); skip this window'}])
    tables.rejected_windows_table()
    tex = (output/'rejected_windows.tex').read_text()
    assert r'sensor\_gap \& loss\_50\% \#1' in tex
    assert r'Valid grid coverage 87.5\%' in tex
