"""Tests of label alignment, deterministic sampling, descriptive summarization."""
import numpy as np
import pytest
from src.ecg_io import ECGRecord
from src.window_analysis import window_label, evenly_spaced_subset, select_stratified_windows, summarize_rows


def synthetic_record(codes):
    return ECGRecord('t00',100.,np.zeros(len(codes)*6000,dtype=np.float64),
                     np.arange(0,len(codes)*6000,100),
                     6000*np.arange(len(codes)),np.asarray(codes,dtype=np.int16))


def test_window_label_must_be_homogeneous():
    r=synthetic_record([1,1,1,8,8,8,1,8,1])
    assert window_label(r,0,180)=='normal'
    assert window_label(r,180,180)=='apnea'
    assert window_label(r,360,180)=='mixed'
    with pytest.raises(ValueError):
        window_label(r,10,180)


def test_stratified_selection_deterministic_and_time_disjoint():
    r=synthetic_record([1]*18+[8]*18)
    p=select_stratified_windows(r,max_per_label=3)
    assert len(p)==6
    assert [v for _,v in p].count('normal')==3
    assert [v for _,v in p].count('apnea')==3
    assert all(p[i+1][0]-p[i][0]>=180 for i in range(len(p)-1))


def test_evenly_spaced_selection_endpoints():
    assert evenly_spaced_subset([0,1,2,3,4,5,6],3)==[0,3,6]


def test_summary_label_grouping():
    rows=[]
    for lbl, vals in [('normal',[10.,20.]),('apnea',[30.,50.])]:
        for sd in vals:
            rows.append({'record':'a01','label':lbl,'sdnn_ms':sd,
                         'welch_bpm':9.,'lomb_bpm':10.,'method_difference_bpm':1.,
                         'interpolation_difference_bpm':0.,'auto_reference_difference_bpm':0.})
    summary=summarize_rows(rows)
    assert summary[0]['median_sdnn_ms']==15.
    assert summary[1]['median_sdnn_ms']==40.
