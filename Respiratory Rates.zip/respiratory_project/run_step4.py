"""Step 4: multi-record stability and exploratory normal/apnea comparison.

Reproduce from directory containing data.zip and Step 1-3 code:
    python run_step4.py --data-zip data.zip

Only complete 3-minute normal and apnea labelled windows are selected.
Four non-overlapping windows per available class/record are spread across time.
This deliberately balanced subset is NOT representative of class prevalence.
Output is descriptive: no independent respiratory signal is analysed here.
Some records in the broader database include additional respiratory channels.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from src.ecg_io import load_record
from src.rpeaks import detect_r_peaks
from src.rr_analysis import rr_from_peaks, spectral_comparison
from src.window_analysis import select_stratified_windows, summarize_rows


from src.output_utils import write_csv as save_csv, stage_run

METRIC_FIELDS = ['record', 'label', 'window_start_s', 'window_duration_s',
                 'n_rr_points', 'grid_coverage', 'mean_rr_ms', 'sdnn_ms',
                 'welch_bpm', 'lomb_bpm', 'pchip_welch_bpm', 'reference_welch_bpm',
                 'method_difference_bpm', 'interpolation_difference_bpm',
                 'auto_reference_difference_bpm']
SUMMARY_FIELDS = ['record', 'label', 'n_windows', 'median_sdnn_ms',
                  'median_welch_bpm', 'median_lomb_bpm',
                  'median_method_difference_bpm',
                  'median_interpolation_difference_bpm',
                  'median_auto_reference_difference_bpm']
SKIPPED_FIELDS = ['record', 'label', 'window_start_s', 'reason']


def save_fig(fig, base: Path) -> None:
    fig.tight_layout()
    for ext in ('.png','.pdf'):
        fig.savefig(base.with_suffix(ext),dpi=165)
    plt.close(fig)


def evaluate_window(rec, detected, reference, start_s: float,
                    duration_s: float, label: str) -> dict:
    """Compare estimation sensitivity without using apnea labels for estimation."""
    kw = {'t_start': start_s, 'duration_s': duration_s}
    linear = spectral_comparison(detected.time_s, detected.rr_s,
                                 method='linear', **kw)
    pchip = spectral_comparison(detected.time_s, detected.rr_s,
                                method='pchip', **kw)
    reference_result = spectral_comparison(reference.time_s, reference.rr_s,
                                           method='linear', **kw)
    time_sel = (detected.time_s >= start_s) & (detected.time_s < start_s+duration_s)
    intervals = detected.rr_s[time_sel]
    mean_rr_ms = float(np.mean(intervals)*1000)
    # Legacy CSV key: cleaned-RR SD, not independently classified clinical SDNN.
    sdnn_ms = float(np.std(intervals, ddof=1)*1000)
    return {
        'record': rec.name, 'label': label,
        'window_start_s': start_s, 'window_duration_s': duration_s,
        'n_rr_points': len(intervals), 'grid_coverage': linear['coverage'],
        'mean_rr_ms': mean_rr_ms, 'sdnn_ms': sdnn_ms,
        'welch_bpm': 60.*linear['welch_peak_hz'],
        'lomb_bpm': 60.*linear['lomb_peak_hz'],
        'pchip_welch_bpm': 60.*pchip['welch_peak_hz'],
        'reference_welch_bpm': 60.*reference_result['welch_peak_hz'],
        'method_difference_bpm': linear['difference_bpm'],
        'interpolation_difference_bpm': 60.*abs(linear['welch_peak_hz']-pchip['welch_peak_hz']),
        'auto_reference_difference_bpm': 60.*abs(linear['welch_peak_hz']-reference_result['welch_peak_hz'])
    }


def figures(rows: list[dict], fig_dir: Path) -> None:
    labels = [('normal','tab:blue'),('apnea','tab:orange')]
    fig, ax = plt.subplots(figsize=(9.5,4.9))
    records = sorted(set(r['record'] for r in rows))
    for j, (label, color) in enumerate(labels):
        for i, record in enumerate(records):
            subset = [r for r in rows if r['record']==record and r['label']==label]
            for k, row in enumerate(subset):
                offset = (-.15 if label == 'normal' else .15)
                ax.scatter(i+offset, row['welch_bpm'], color=color, s=28,
                           alpha=.70, label=label.title() if i==0 and k==0 else None)
            if subset:
                med=np.median([r['welch_bpm'] for r in subset])
                ax.plot([i+offset-.095,i+offset+.095],[med,med],
                        lw=2.8,color=color)
    ax.set(xticks=range(len(records)),xticklabels=records,
           ylabel='RR-spectrum candidate frequency (cycles/min)',
           title='Detected R-R Welch peaks: record and label stratified windows')
    ax.grid(axis='y',alpha=.22)
    ax.legend(loc='best')
    save_fig(fig,fig_dir/'fig_candidate_frequency_by_label')

    fig, axes=plt.subplots(1,2,figsize=(10.5,4.1))
    for ax,metric,title in [
        (axes[0],'method_difference_bpm','Welch vs Lomb-Scargle'),
        (axes[1],'auto_reference_difference_bpm','Detected vs annotated QRS')]:
        data=[r[metric] for r in rows]
        ax.hist(data,bins=np.arange(0,max(5.,np.ceil(max(data))+1.),1.),
                edgecolor='white',alpha=.85)
        ax.set(xlabel='Absolute candidate peak difference (cycles/min)',
               ylabel='Number of windows',title=title)
        ax.grid(axis='y',alpha=.2)
    fig.suptitle('Candidate frequency differences across methods')
    save_fig(fig,fig_dir/'fig_method_sensitivity')

    fig, ax=plt.subplots(figsize=(8.7,4.4))
    for label,color in labels:
        # Distinguish records to avoid implying windows are independent patients.
        data=[r['sdnn_ms'] for r in rows if r['label']==label]
        if data:
            ax.hist(data, bins=12, alpha=.50, color=color,label=f'{label.title()} (n={len(data)})')
    ax.set(xlabel='Cleaned-RR SD (ms)',ylabel='Number of sampled windows',
           title='Exploratory R-R variability, not apnea classification')
    ax.legend();ax.grid(axis='y',alpha=.2)
    save_fig(fig,fig_dir/'fig_rr_variability_by_label')


def main(args) -> None:
    parameters = {'data_zip': str(args.data_zip), 'records': args.records,
                  'duration_s': args.duration_s, 'max_per_label': args.max_per_label,
                  'fs_grid_hz': 4., 'max_gap_s': 3., 'frequency_band_hz': [.10, .40]}
    with stage_run(args.output_dir, 'step4', parameters) as metadata:
        _analyse(args, metadata)


def _analyse(args, metadata) -> None:
    fig_dir=args.output_dir/'figures'
    res_dir=args.output_dir/'results'
    fig_dir.mkdir(parents=True,exist_ok=True)
    res_dir.mkdir(parents=True,exist_ok=True)
    results=[]
    skip=[]
    for name in args.records:
        rec=load_record(args.data_zip,name)
        if not len(rec.apnea_labels):
            print(f'{name}: no .apn annotation, excluded from label comparison')
            continue
        plans=select_stratified_windows(rec,duration_s=args.duration_s,
                                        max_per_label=args.max_per_label)
        print(f'{name}: selected {len(plans)} windows; ' +
              ', '.join(f'{label}={sum(l==label for _,l in plans)}'
                        for label in ['normal','apnea']))
        det=rr_from_peaks(detect_r_peaks(rec.ecg_mv,rec.fs),rec.fs)
        ref=rr_from_peaks(rec.qrs_samples,rec.fs)
        for start,label in plans:
            try:
                item=evaluate_window(rec,det,ref,start,args.duration_s,label)
                results.append(item)
            except ValueError as exc:
                skip.append({'record':name,'label':label,'window_start_s':start,
                             'reason':str(exc)})
    save_csv(res_dir/'rr_window_metrics.csv',results, fieldnames=METRIC_FIELDS)
    summary=summarize_rows(results)
    save_csv(res_dir/'rr_window_summary.csv',summary, fieldnames=SUMMARY_FIELDS)
    save_csv(res_dir/'rr_skipped_windows.csv',skip, fieldnames=SKIPPED_FIELDS)
    metadata.update(accepted_windows=len(results), skipped_windows=len(skip))
    if not results:
        raise RuntimeError('All windows rejected; adjust records or window parameters')
    figures(results,fig_dir)
    print(f'Analysed: {len(results)} windows; skipped: {len(skip)}')
    print('Results: results/rr_window_metrics.csv, results/rr_window_summary.csv')
    print('Figures: figures/fig_candidate_frequency_by_label, '
          'figures/fig_method_sensitivity, figures/fig_rr_variability_by_label')
    for row in summary:
        print(f"{row['record']} {row['label']} n={row['n_windows']} "
              f"median cleaned-RR SD={row['median_sdnn_ms']:.1f} ms; "
              f"Welch={row['median_welch_bpm']:.2f}, "
              f"Lomb={row['median_lomb_bpm']:.2f} cycles/min; "
              f"median method difference={row['median_method_difference_bpm']:.2f}")
    print('No independent respiratory signal was analysed; peaks remain unvalidated candidates.')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-zip',type=Path,default=Path('data.zip'))
    parser.add_argument('--records',nargs='+',default=['a05','a10','b05','c01'])
    parser.add_argument('--duration-s',type=float,default=180.)
    parser.add_argument('--max-per-label',type=int,default=4)
    parser.add_argument('--output-dir',type=Path,default=Path('.'))
    main(parser.parse_args())
