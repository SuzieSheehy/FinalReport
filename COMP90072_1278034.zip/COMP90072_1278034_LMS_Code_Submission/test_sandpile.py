"""Correctness tests for actual dynamics, not just implementation details.

Run: python3 -m unittest -v test_sandpile
"""
import random
import contextlib
import csv
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import sandpile
from sandpile import Sandpile, scan_add, addition_sites, simulate


class SandpileTests(unittest.TestCase):
    def test_zero_event(self):
        pile = Sandpile(5)
        self.assertEqual(pile.add(12)[0], (0,0,0,0,1))

    def isolated(self, site, loss, neighbours):
        pile = Sandpile(5)
        pile.h[site] = 3
        pile.mass = 3
        event, counts = pile.add(site)
        self.assertEqual(event, (1,1,loss,0,4-loss))
        self.assertEqual(counts, {site:1})
        self.assertEqual({i for i,h in enumerate(pile.h) if h}, set(neighbours))

    def test_interior(self):
        self.isolated(12, 0, [7,11,13,17])

    def test_edge(self):
        self.isolated(2, 1, [1,3,7])

    def test_corner(self):
        self.isolated(0, 2, [1,5])

    def test_one_site_sink(self):
        pile = Sandpile(1, [3])
        self.assertEqual(pile.add(0)[0], (1,1,4,0,0))

    def test_order_independence_and_conservation(self):
        # 80 high-occupancy/random stable configurations, two grid sizes.
        rng = random.Random(741)
        for length in (5,9):
            for case in range(40):
                heights = [3 if case < 10 else rng.randrange(4) for _ in range(length**2)]
                site = rng.randrange(length**2)
                queue, stack = Sandpile(length, heights), Sandpile(length, heights)
                reference = list(heights)
                a = queue.add(site, 'queue')
                b = stack.add(site, 'stack')
                c = scan_add(reference, length, site)
                self.assertEqual(a,b)
                self.assertEqual(a,c)
                self.assertEqual(queue.h,reference)
                self.assertEqual(stack.h,reference)
                self.assertEqual(sum(reference),sum(heights)+1-a[0][2])
                self.assertTrue(all(0 <= h <= 3 for h in reference))

    def test_sequence_reproducible(self):
        for drive in ('uniform','biased'):
            first=list(addition_sites(drive,511,1000))
            self.assertEqual(first,list(addition_sites(drive,511,1000)))
            self.assertNotEqual(first,list(addition_sites(drive,512,1000)))

    def test_drive_patch_frequency(self):
        patch={r*31+c for r in (14,15,16) for c in (14,15,16)}
        for drive,expected in [('uniform',9/961),('biased',.8+.2*9/961)]:
            observed=sum(site in patch for site in addition_sites(drive,861,100000))/100000
            self.assertLess(abs(observed-expected),.005)


class InputValidationTests(unittest.TestCase):
    """Invalid calls must fail before changing a grid or saved output."""

    def test_invalid_grid_lengths(self):
        for value in (True, False, 2.0, '2', None):
            with self.subTest(length=value), self.assertRaises(TypeError):
                Sandpile(value)
        for value in (0, -1):
            with self.subTest(length=value), self.assertRaises(ValueError):
                Sandpile(value)

    def test_invalid_initial_height_lengths(self):
        for heights in ([], [0]*3, [0]*5, [[0,0],[0,0]]):
            with self.subTest(heights=heights), self.assertRaises(ValueError):
                Sandpile(2, heights)
        with self.assertRaises(TypeError):
            Sandpile(2, 3)

    def test_invalid_initial_height_types_and_ranges(self):
        for value in (True, False, 1.0, '1', None):
            with self.subTest(height=value), self.assertRaises(TypeError):
                Sandpile(2, [value,0,0,0])
        for value in (-1, 4, 100):
            with self.subTest(height=value), self.assertRaises(ValueError):
                Sandpile(2, [value,0,0,0])

    def test_constructor_copies_iterable(self):
        original = [0,1,2,3]
        pile = Sandpile(2, iter(original))
        original[3] = 0
        self.assertEqual(pile.h, [0,1,2,3])
        self.assertEqual(pile.mass, 6)

    def test_invalid_add_sites_preserve_state(self):
        for site, error in [(-1, ValueError), (4, ValueError), (10, ValueError),
                            (True, TypeError), (1.0, TypeError), ('1', TypeError),
                            (None, TypeError)]:
            with self.subTest(site=site):
                pile = Sandpile(2, [3]*4)
                before = (pile.h.copy(), pile.mass, pile.queued.copy())
                with self.assertRaises(error):
                    pile.add(site)
                self.assertEqual((pile.h, pile.mass, pile.queued), before)
                self.assertEqual(pile.add(0), Sandpile(2, [3]*4).add(0))

    def test_invalid_orders_preserve_state(self):
        for order, error in [('fifo', ValueError), ('Queue', ValueError),
                             ('', ValueError), (None, TypeError), ([], TypeError)]:
            with self.subTest(order=order):
                pile = Sandpile(2, [3]*4)
                before = (pile.h.copy(), pile.mass, pile.queued.copy())
                with self.assertRaises(error):
                    pile.add(0, order)
                self.assertEqual((pile.h, pile.mass, pile.queued), before)

    def test_scan_rejects_invalid_arguments_without_mutation(self):
        cases = [([3]*4, 0, 0, ValueError), ([3]*4, 2.0, 0, TypeError),
                 ([3]*4, 2, -1, ValueError), ([3]*4, 2, 4, ValueError),
                 ([3]*4, 2, True, TypeError), ([3]*4, 2, 1.0, TypeError),
                 ([3]*3, 2, 0, ValueError), ([4,0,0,0], 2, 3, ValueError),
                 ([-1,0,0,0], 2, 0, ValueError), ([0,0,0,1.0], 2, 0, TypeError),
                 ([0,0,0,False], 2, 0, TypeError), ((0,0,0,0), 2, 0, TypeError)]
        for heights, length, site, error in cases:
            with self.subTest(heights=heights, length=length, site=site):
                before = list(heights)
                with self.assertRaises(error):
                    scan_add(heights, length, site)
                self.assertEqual(list(heights), before)

    def test_invalid_drives_are_rejected_immediately(self):
        for drive in ('typo', 'Uniform', ''):
            with self.subTest(drive=drive), self.assertRaises(ValueError):
                addition_sites(drive, 1, 0)
        for drive in (None, 0, [], True):
            with self.subTest(drive=drive), self.assertRaises(TypeError):
                addition_sites(drive, 1, 0)

    def test_invalid_addition_counts_and_lengths(self):
        for drive in ('uniform', 'biased'):
            for value, error in [(-1, ValueError), (1.0, TypeError),
                                 (True, TypeError), ('1', TypeError), (None, TypeError)]:
                with self.subTest(drive=drive, count=value), self.assertRaises(error):
                    addition_sites(drive, 1, value)
            for value, error in [(0, ValueError), (-1, ValueError), (2.0, TypeError),
                                 (True, TypeError), ('3', TypeError), (None, TypeError)]:
                with self.subTest(drive=drive, length=value), self.assertRaises(error):
                    addition_sites(drive, 1, 10, value)
        for length in (1,2):
            with self.subTest(biased_length=length), self.assertRaises(ValueError):
                addition_sites('biased', 1, 0, length)

    def test_small_valid_grids_and_empty_sequences(self):
        for drive, length in [('uniform',1), ('uniform',2), ('biased',3), ('biased',4)]:
            with self.subTest(drive=drive, length=length):
                self.assertEqual(list(addition_sites(drive, 1, 0, length)), [])
                sites = list(addition_sites(drive, 1, 1000, length))
                self.assertEqual(len(sites), 1000)
                self.assertTrue(all(0 <= site < length**2 for site in sites))
        for order in ('queue','stack'):
            self.assertEqual(Sandpile(1, [3]).add(0, order)[0], (1,1,4,0,0))

    def test_unsupported_seed_rejected(self):
        with self.assertRaises(TypeError):
            addition_sites('uniform', object(), 10)

    def test_invalid_simulation_arguments_preserve_output(self):
        cases = [({'drive':'typo'}, ValueError), ({'drive':None}, TypeError),
                 ({'count':0}, ValueError), ({'count':-1}, ValueError),
                 ({'count':1.5}, TypeError), ({'count':True}, TypeError),
                 ({'burn_in':-1}, ValueError), ({'burn_in':2}, ValueError),
                 ({'burn_in':3}, ValueError), ({'burn_in':0.0}, TypeError),
                 ({'burn_in':False}, TypeError), ({'seed':object()}, TypeError)]
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory)/'existing.csv'
            original = b'existing evidence\n'
            destination.write_bytes(original)
            for changes, error in cases:
                args = dict(drive='uniform', seed=1, count=2, output=destination, burn_in=0)
                args.update(changes)
                with self.subTest(changes=changes), self.assertRaises(error):
                    simulate(**args)
                self.assertEqual(destination.read_bytes(), original)

    def test_simulation_sampling_edges(self):
        with tempfile.TemporaryDirectory() as directory:
            for count, burn_in in [(1,0), (2,1)]:
                path = Path(directory)/f'{count}.csv'
                result = simulate('uniform', 1, count, path, burn_in)
                with path.open(newline='') as stream:
                    rows = list(csv.DictReader(stream))
                self.assertEqual(len(rows), count)
                self.assertEqual(int(rows[-1]['step']), count)
                self.assertEqual(result['burn_in'], burn_in)

    def test_cli_rejects_invalid_counts_before_output(self):
        for mode in ('production','pilot','timing'):
            for flag, value in [('--burn-in','-1'), ('--samples','0'),
                                ('--samples','-1'), ('--samples','1.5')]:
                with self.subTest(mode=mode, flag=flag, value=value):
                    with tempfile.TemporaryDirectory() as directory:
                        output = Path(directory)
                        with patch.object(sandpile, 'ROOT', output), patch('sys.argv',
                                ['sandpile.py',mode,flag,value]), contextlib.redirect_stderr(io.StringIO()):
                            with self.assertRaises(SystemExit) as caught:
                                sandpile.main()
                        self.assertEqual(caught.exception.code, 2)
                        self.assertFalse((output/'results').exists())


if __name__ == '__main__':
    unittest.main()
