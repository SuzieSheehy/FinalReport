"""Reproduce the finite-lattice theoretical values in main.tex.

This solves the discrete Poisson equation. It is not a sandpile simulation.
Requires Python 3 and NumPy. Run from any working directory.
Stationary mean-response identity: Dhar, The abelian sandpile and related
models, https://arxiv.org/abs/cond-mat/9808047, equation (10).
"""

import json
from pathlib import Path

import numpy as np


def laplacian(x):
    """Apply the positive-diagonal open-grid Laplacian to a 2D numeric array.

    Return a new floating-point array with the same shape as x. The diagonal
    is four even at boundary sites; missing neighbours have exterior value
    zero. This is the operator in main.tex, Eq. labelled eq:matrix. x is not
    modified. The caller supplies a nonempty, real-valued 2D NumPy array.
    """
    result = 4.0 * x.copy()
    result[1:, :] -= x[:-1, :]
    result[:-1, :] -= x[1:, :]
    result[:, 1:] -= x[:, :-1]
    result[:, :-1] -= x[:, 1:]
    return result


def poisson(source):
    """Solve Delta u = source on a square open grid by sine diagonalization.

    source is a finite real-valued NumPy array of shape (L, L), with L >= 1.
    Return a new floating-point solution array of the same shape without
    modifying source. Exterior values are zero; Delta retains diagonal four
    on edges and corners, matching laplacian() and the report's convention.

    The orthonormal sine basis diagonalizes the 1D second-difference matrix.
    Its eigenvalues are 2 - 2*cos(pi*j/(L+1)), j=1,...,L; the 2D eigenvalues
    are pairwise sums. Transform the right-hand side, divide each coefficient
    by its eigenvalue, and transform back. See main.tex, 'Exact finite-lattice
    benchmarks' (sec:benchmarks), for this spectrum and its use in the mean
    response identity. The caller is responsible for the square-array input.
    """
    length = source.shape[0]
    k = np.arange(1, length + 1)
    basis = np.sqrt(2.0 / (length + 1)) * np.sin(
        np.pi * np.outer(k, k) / (length + 1)
    )
    eigenvalues = 2.0 - 2.0 * np.cos(np.pi * k / (length + 1))
    coefficients = basis.T @ source @ basis
    solution = basis @ (
        coefficients / (eigenvalues[:, None] + eigenvalues[None, :])
    ) @ basis.T
    return solution


def main():
    length = 31
    uniform = np.full((length, length), 1.0 / length**2)
    patch = np.zeros_like(uniform)
    patch[14:17, 14:17] = 1.0 / 9
    biased = 0.2 * uniform + 0.8 * patch
    response = poisson(np.ones_like(uniform))

    # Independent one-dimensional second-difference construction.
    one_d = np.diag(np.full(length, 2.0))
    one_d += np.diag(np.full(length - 1, -1.0), 1)
    one_d += np.diag(np.full(length - 1, -1.0), -1)
    matrix = np.kron(np.eye(length), one_d) + np.kron(one_d, np.eye(length))
    direct_response = np.linalg.solve(matrix, np.ones(length**2))
    assert np.allclose(response.ravel(), direct_response, atol=1e-10, rtol=0)
    assert np.allclose(poisson(np.ones((1, 1))), [[0.25]])

    cases = {}
    for label, probability in [("uniform", uniform), ("centre_biased", biased)]:
        assert np.isclose(probability.sum(), 1.0)
        assert np.all(probability > 0)
        topplings = poisson(probability)
        loss = (topplings[0, :].sum() + topplings[-1, :].sum()
                + topplings[:, 0].sum() + topplings[:, -1].sum())
        mean_s = float(topplings.sum())
        assert np.isclose(mean_s, np.sum(probability * response))
        assert np.isclose(loss, 1.0)
        cases[label] = {
            "mean_topplings_per_addition": mean_s,
            "mean_loss_per_addition": float(loss),
            "max_poisson_residual": float(np.max(np.abs(laplacian(topplings) - probability))),
            "central_patch_probability": float(probability[14:17, 14:17].sum()),
        }
    results = {
        "calculation_type": "stationary theoretical benchmark, not simulation",
        "lattice_size": length,
        "boundary": "open; diagonal 4 including edges and corners",
        "centre_patch_one_based": [15, 16, 17],
        "mixture_weight": 0.8,
        "cases": cases,
        "toppling_mean_ratio": cases["centre_biased"]["mean_topplings_per_addition"] / cases["uniform"]["mean_topplings_per_addition"],
        "direct_vs_spectral_max_difference": float(np.max(np.abs(response.ravel() - direct_response))),
        "response_residual": float(np.max(np.abs(laplacian(response) - 1))),
        "centre_row_response": [float(value) for value in response[15, :]],
        "numpy_version": np.__version__,
    }
    destination = Path(__file__).with_name("benchmark_results.json")
    destination.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
