"""Regression checks for replay failures and data-driven report figures.

Run with test_sandpile under normal Python and python -O. Requires NumPy.
Fixtures are isolated from the saved experiment and include deliberately
incorrect records, changed summary values, and corrupted figure labels.
"""
import contextlib
import copy
import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import analyse_results
import audit_project
from sandpile import simulate


class ReplayRegressionTests(unittest.TestCase):
    def run_replay(self, change=None):
        """Run a fresh fixture in each interpreter mode, never using saved CSVs."""
        for flags in ([], ['-O']):
            with self.subTest(flags=flags, change=change), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                results = root / 'results'
                results.mkdir()
                source = Path(__file__).resolve().parent
                for name in ('sandpile.py', 'verify_saved_results.py'):
                    shutil.copyfile(source / name, root / name)
                destination = results / 'production_uniform_101.csv'
                run = simulate('uniform', 101, 1000, destination, 0)
                (results / 'production_metadata.json').write_text(json.dumps({'runs': [run]}))
                if change:
                    with destination.open(newline='') as stream:
                        reader = csv.DictReader(stream)
                        fields, rows = reader.fieldnames, list(reader)
                    if change == 'missing_row':
                        rows.pop()
                    else:
                        rows[0][change] = str(int(rows[0][change]) + 1)
                    with destination.open('w', newline='') as stream:
                        writer = csv.DictWriter(stream, fieldnames=fields)
                        writer.writeheader()
                        writer.writerows(rows)
                process = subprocess.run(
                    [sys.executable, *flags, str(root / 'verify_saved_results.py')],
                    cwd=root, capture_output=True, text=True, timeout=30)
                result_file = results / 'replay_validation.json'
                if change:
                    self.assertNotEqual(process.returncode, 0, process.stdout)
                    self.assertIn('mismatch' if change != 'S' else '!= saved', process.stderr)
                    self.assertFalse(result_file.exists())
                else:
                    self.assertEqual(process.returncode, 0, process.stderr)
                    result = json.loads(result_file.read_text())
                    self.assertEqual(result['total_events'], 1000)
                    self.assertTrue(result['checks'][0]['all_sites_and_metrics_match'])

    def test_valid_records_pass_in_both_modes(self):
        self.run_replay()

    def test_corrupt_records_fail_in_both_modes(self):
        for change in ('S', 'site', 'step', 'missing_row'):
            self.run_replay(change)


class CoreFigureRegressionTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.output = Path(directory.name)
        patches = contextlib.ExitStack()
        self.addCleanup(patches.close)
        patches.enter_context(patch.object(analyse_results, 'OUT', self.output))
        patches.enter_context(patch.object(audit_project, 'OUT', self.output))
        self.summary = {
            'primary_window': [101, 200],
            'groups': {
                'uniform': {'S': 40.0, 'height': 2.1, 'D': 0.9, 'n': 200, 'runs': [{}, {}]},
                'biased': {'S': 80.0, 'height': 2.2, 'D': 1.1, 'n': 200, 'runs': [{}, {}]},
            },
        }
        self.path = self.output / 'core_comparison_plot.tex'

    def test_missing_figure_is_generated_from_summary(self):
        self.assertFalse(self.path.exists())
        analyse_results.write_core_comparison(self.summary)
        self.assertEqual(audit_project.check_core_comparison(self.summary['groups']), 6)
        text = self.path.read_text()
        self.assertIn('101--200 from each of 2 runs, or 200 additions', text)
        self.assertIn(r'100.00\%', text)

    def test_changed_summary_updates_values_labels_and_caption(self):
        analyse_results.write_core_comparison(self.summary)
        changed = copy.deepcopy(self.summary)
        changed['groups']['biased'].update(S=120.0, height=2.4, D=1.05)
        analyse_results.write_core_comparison(changed)
        self.assertEqual(audit_project.check_core_comparison(changed['groups']), 6)
        text = self.path.read_text()
        self.assertIn('coordinates {(2,120.0)}', text)
        self.assertIn('{120.0000};', text)
        self.assertIn(r'200.00\%', text)
        self.assertIn('ymax=144', text)
        self.assertNotIn('coordinates {(2,80.0)}', text)

    def test_audit_rejects_corrupt_bars_labels_and_missing_series(self):
        analyse_results.write_core_comparison(self.summary)
        original = self.path.read_text()
        bar_line = next(line for line in original.splitlines(True) if 'coordinates' in line)
        mutations = [
            original.replace('coordinates {(1,40.0)}', 'coordinates {(1,41.0)}', 1),
            original.replace('{40.0000};', '{41.0000};', 1),
            original.replace('(axis cs:1,40.0)', '(axis cs:2,40.0)', 1),
            original.replace(bar_line, '', 1),
            original + bar_line,
        ]
        for index, text in enumerate(mutations):
            with self.subTest(mutation=index):
                self.path.write_text(text)
                with self.assertRaises(AssertionError):
                    audit_project.check_core_comparison(self.summary['groups'])


if __name__ == '__main__':
    unittest.main()
