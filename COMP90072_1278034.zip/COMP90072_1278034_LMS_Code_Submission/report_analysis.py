"""Validate saved events and build additional report tables/PGFPlots.

Run: python3 report_analysis.py
Requires NumPy; reads the existing CSVs without changing them. The primary
window is additions 20,001--40,000 in each of three runs per driving rule.
Power-law fits are descriptive discrete MLEs, not independent-event tests.
See Clauset et al. (2009), https://doi.org/10.1137/070710111.
Outputs: results/report_analysis.json and *_report.tex snippets.
"""
import hashlib
import json
import math
import platform
from pathlib import Path

import numpy as np

from analyse_results import coordinates, summarise
from theoretical_benchmark import poisson

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results'


def zeta_tail(alpha, xmin):
    """Hurwitz zeta via a finite sum plus Euler--Maclaurin tail.

    For caller-supplied alpha > 1 and positive integer xmin, return a float
    approximating sum(k**(-alpha), k=xmin,...,infinity). This is the unbounded
    discrete power-law normalizer in main.tex, Eq. labelled eq:tail. The
    Euler--Maclaurin tail approximation includes the integral, half-endpoint term
    and the B2/B4 derivative corrections shown explicitly below.

    The tail starts at 10,000 or later. Corrections through B4 make numerical
    error negligible for the fitting interval 1.01 <= alpha <= 8 used here.
    """
    stop = max(10000, int(xmin) + 1000)
    grid = np.arange(xmin, stop, dtype=float)
    tail = (stop ** (1 - alpha) / (alpha - 1)
            + 0.5 * stop ** (-alpha)
            + alpha / 12 * stop ** (-alpha - 1)
            - alpha * (alpha + 1) * (alpha + 2) / 720 * stop ** (-alpha - 3))
    return float(np.sum(grid ** (-alpha)) + tail)


def golden_minimum(function, lower=1.01, upper=8.0):
    """Approximate a scalar minimizer by bounded golden-section search.

    function must return finite real values and be unimodal on the finite
    interval lower < upper. Return the midpoint of the remaining bracket
    after 90 reductions. The golden ratio preserves one interior evaluation
    at each step, so only one new function value is needed per reduction.
    Here the objective is the negative log likelihood of the discrete power
    law in main.tex, Eq. labelled eq:tail; fit_tail() checks for a solution
    near the search bounds. The caller supplies a valid bracket and objective.
    """
    ratio = (math.sqrt(5) - 1) / 2
    x1, x2 = upper - ratio * (upper-lower), lower + ratio * (upper-lower)
    f1, f2 = function(x1), function(x2)
    for _ in range(90):
        if f1 < f2:
            upper, x2, f2 = x2, x1, f1
            x1 = upper - ratio * (upper-lower)
            f1 = function(x1)
        else:
            lower, x1, f1 = x1, x2, f2
            x2 = lower + ratio * (upper-lower)
            f2 = function(x2)
    return (lower + upper) / 2


def fit_tail(values, xmin):
    """Fit unbounded integer power-law and shifted geometric tails.

    values is a 1D NumPy array of nonnegative integer observations; xmin is
    a positive integer cutoff. Only values >= xmin enter either likelihood.
    The retained sample must be nonempty and have positive mean excess above
    xmin, giving 0 < geometric q < 1. The power-law search uses alpha in
    [1.01, 8] and rejects estimates near its bounds. Inputs are not modified.

    Returns alpha, geometric q, empirical CDF distances, likelihood difference
    per observation, and retained tail count; no p-value or confidence interval.
    The KS distance is evaluated at every integer, including unobserved gaps.
    """
    sample = values[values >= xmin].astype(int)
    n = len(sample)
    log_sum = float(np.log(sample).sum())
    objective = lambda alpha: n * math.log(zeta_tail(alpha, xmin)) + alpha * log_sum
    alpha = golden_minimum(objective)
    assert 1.02 < alpha < 7.99, 'Fit reached parameter boundary'
    grid = np.arange(xmin, int(sample.max()) + 1)
    empirical = np.cumsum(np.bincount(sample-xmin, minlength=len(grid))) / n
    power_cdf = np.cumsum(grid.astype(float) ** (-alpha)) / zeta_tail(alpha, xmin)
    excess = sample - xmin
    q = 1 / (1 + float(excess.mean()))
    geometric_cdf = 1 - (1-q) ** (grid-xmin+1)
    ll_power = -objective(alpha)
    ll_geometric = n * math.log(q) + int(excess.sum()) * math.log1p(-q)
    return dict(xmin=xmin, n=n, alpha=alpha, geometric_q=q,
                ks_power=float(np.max(np.abs(empirical-power_cdf))),
                ks_geometric=float(np.max(np.abs(empirical-geometric_cdf))),
                log_likelihood_difference_per_event=(ll_power-ll_geometric)/n)


def table(filename, caption, label, header, rows, alignment):
    text = [r'\begin{table}[htbp]', r'\centering', r'\small',
            r'\caption{' + caption + '}', r'\label{' + label + '}',
            r'\begin{tabular}{@{}' + alignment + r'@{}}', r'\toprule',
            ' & '.join(header) + r'\\', r'\midrule']
    text += [' & '.join(row) + r'\\' for row in rows]
    text += [r'\bottomrule', r'\end{tabular}', r'\end{table}']
    (OUT / filename).write_text('\n'.join(text) + '\n')


def main():
    assert abs(zeta_tail(2, 1) - math.pi**2/6) < 1e-12
    assert abs(zeta_tail(4, 1) - math.pi**4/90) < 1e-12
    assert abs(zeta_tail(2, 20)-zeta_tail(2, 21)-20**-2) < 1e-13
    metadata = json.loads((OUT / 'production_metadata.json').read_text())
    arrays, checks = {'uniform': [], 'biased': []}, []
    for run in metadata['runs']:
        path = OUT / run['csv']
        data = np.genfromtxt(path, delimiter=',', names=True, dtype=np.int64)
        assert len(data) == 60000
        assert np.array_equal(data['step'], np.arange(1, 60001))
        assert np.all((data['site'] >= 0) & (data['site'] < 961))
        previous = np.r_[0, data['mass'][:-1]]
        assert np.array_equal(data['mass'], previous + 1 - data['D'])
        assert np.all((data['mass'] >= 0) & (data['mass'] <= 3*961))
        assert np.all((data['A'] >= 0) & (data['A'] <= 961) & (data['S'] >= data['A']))
        assert np.all((data['D'] >= 0) & (data['R'] >= 0) & (data['R'] <= 60))
        zero = data['S'] == 0
        assert all(np.all(data[name][zero] == 0) for name in ('A', 'D', 'R'))
        assert np.all(data['A'][~zero] > 0)
        assert int(data['S'].sum()) == run['topplings']
        arrays[run['drive']].append(data)
        checks.append(dict(file=path.name, rows=len(data), seed=run['seed'],
                           sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                           every_event_mass_balance=True, metric_bounds=True))

    report = dict(python=platform.python_version(), numpy=np.__version__,
                  primary_window=[20001, 40000], source_checks=checks, groups={})
    pooled = {drive: np.concatenate([x[20000:40000] for x in runs])
              for drive, runs in arrays.items()}
    saved = json.loads((OUT / 'analysis.json').read_text())
    response = poisson(np.ones((31,31)))
    uniform_mean = float(response.mean())
    patch_mean = float(response[14:17,14:17].mean())
    report['linear_response'] = dict(uniform_mean=uniform_mean, patch_mean=patch_mean,
                                     slope=patch_mean-uniform_mean)
    report['mean_response_decomposition'] = {}
    for drive, data in pooled.items():
        group = summarise(data)
        for key in ('S', 'A', 'D', 'R', 'height', 'avalanche_probability'):
            assert abs(group[key]-saved['groups'][drive][key]) < 1e-10
        avalanche = data[data['S'] > 0]
        group['mean_R_conditional'] = float(avalanche['R'].mean())
        group['mean_D_positive'] = float(data['D'][data['D'] > 0].mean())
        group['positive_loss_count'] = int(np.count_nonzero(data['D']))
        group['positive_loss_probability'] = group['positive_loss_count'] / len(data)
        assert abs(group['positive_loss_probability'] * group['mean_D_positive'] - group['D']) < 1e-12
        group['maxima'] = {key: int(data[key].max()) for key in ('S', 'A', 'D', 'R')}
        group['tail_fits'] = {key: [fit_tail(data[key], lower) for lower in (20, 50, 100, 200)]
                              for key in ('S', 'A')}
        report['groups'][drive] = group

        # The balance identity gives the weighted endpoint term from stored
        # sites and counts. audit_project.py verifies it independently using
        # the actual endpoint grids from synchronous relaxation, not mass.
        theoretical_mean = uniform_mean if drive == 'uniform' else .2*uniform_mean + .8*patch_mean
        run_terms = []
        run_metadata = [run for run in metadata['runs'] if run['drive'] == drive]
        for run, raw in zip(run_metadata, arrays[drive]):
            selected = raw[20000:40000]
            mean_s = float(selected['S'].mean())
            mean_input = float(response.ravel()[selected['site']].mean())
            run_terms.append(dict(file=run['csv'], mean_S=mean_s,
                                  mean_input_response=mean_input,
                                  endpoint_term=mean_s-mean_input))
        mean_input = float(np.mean([run['mean_input_response'] for run in run_terms]))
        endpoint = float(np.mean([run['endpoint_term'] for run in run_terms]))
        report['mean_response_decomposition'][drive] = dict(
            theoretical_mean=theoretical_mean, mean_minus_theory=group['S']-theoretical_mean,
            mean_input_response=mean_input, input_sampling_term=mean_input-theoretical_mean,
            endpoint_term=endpoint, runs=run_terms)
        assert abs(mean_input+endpoint-group['S']) < 1e-10
    (OUT / 'report_analysis.json').write_text(json.dumps(report, indent=2) + '\n')

    linear = [r'\begin{equation}',
              rf' \E_w[S]\simeq {uniform_mean:.8f}+{patch_mean-uniform_mean:.8f}\,w,\qquad 0\leq w<1.',
              r' \label{eq:linearresponse}', r'\end{equation}',
              rf'The central-patch mean is $\E_C[S]\simeq {patch_mean:.8f}$. '
              'The linear dependence is exact for this fixed lattice and patch; '
              'the displayed coefficients are rounded.']
    (OUT/'linear_response_report.tex').write_text('\n'.join(linear)+'\n')

    table('mean_error_report.tex',
          'Primary-window mean toppling deviation from the stationary prediction, '
          'averaged over three equal-length runs per drive. The input-sampling and '
          'weighted-endpoint terms sum to the deviation before rounding. '
          'The signed contributions are measured in topplings per addition.',
          'tab:meanerror', ['Drive', r'$\bar S-\mu_p$', 'Input sampling', 'Weighted endpoint'],
          [[label]+[f'{report["mean_response_decomposition"][drive][key]:.6f}'
                    for key in ('mean_minus_theory','input_sampling_term','endpoint_term')]
           for drive,label in [('uniform','Uniform'),('biased','Centre-biased')]], 'lrrr')

    table('dissipation_report.tex',
          'Loss decomposition in the primary window. Positive-loss probability uses all additions; '
          'conditional mean loss uses only events with positive loss. Their product equals the '
          'all-addition mean loss before rounding. Loss is measured in grains.',
          'tab:dissipation', ['Drive', r'$\widehat{\Prob}(D>0)$',
                              r'$\widehat{\E}[D\mid D>0]$', r'$\widehat{\E}[D]$'],
          [[label]+[f'{report["groups"][drive][key]:.6f}'
                    for key in ('positive_loss_probability','mean_D_positive','D')]
           for drive,label in [('uniform','Uniform'),('biased','Centre-biased')]], 'lrrr')

    rows = []
    for metric in ('S', 'A'):
        for drive, label in [('uniform', 'Uniform'), ('biased', 'Centre-biased')]:
            for result in report['groups'][drive]['tail_fits'][metric]:
                if result['xmin'] not in (20, 100):
                    continue
                rows.append([f'${metric}$', label, str(result['xmin']), str(result['n']),
                             f'{result["alpha"]:.3f}', f'{result["ks_power"]:.3f}',
                             f'{result["ks_geometric"]:.3f}',
                             f'{result["log_likelihood_difference_per_event"]:.5f}'])
    table('tail_report.tex',
          'Exploratory tail fits on the primary window. The power-law exponent changes '
          'with the lower cutoff. $K$ is the maximum empirical--model CDF distance. '
          '$\\Delta\\ell/n=(\\ell_{\\rm PL}-\\ell_{\\rm geom})/n_{\\rm tail}$; '
          'negative values favour the geometric model in likelihood. '
          'Both models have unbounded support and omit '
          'the finite lattice cutoff. All cutoffs, including 50 and 200, '
          'are saved in the analysis JSON.',
          'tab:tail', ['Metric', 'Drive', r'$x_{\min}$', r'$n_{\rm tail}$',
                       r'$\widehat\alpha$', r'$K_{\rm PL}$', r'$K_{\rm geom}$',
                       r'$\Delta\ell/n$'], rows, r'll@{\hspace{2em}}rrrrrr')

    loss = [r'\begin{figure}[htbp]', r'\centering', r'\begin{tikzpicture}',
            r'\begin{axis}[width=0.90\linewidth,height=5.2cm,xlabel={Retained additions per run},ylabel={Cumulative mean loss},xmin=0,xmax=40000,ymin=0.94,ymax=1.06,grid=major,grid style={gray!15},legend pos=south east,legend style={font=\small},tick label style={font=\small}]']
    ns = np.arange(1000, 40001, 500)
    for drive, color, label in [('uniform','teal','Uniform'),('biased','amber','Centre-biased')]:
        ys = np.mean([np.cumsum(x['D'][20000:60000])[ns-1]/ns for x in arrays[drive]], axis=0)
        loss += [rf'\addplot[{color},thick] coordinates {{' + coordinates(ns, ys) + '};',
                 rf'\addlegendentry{{{label}}}']
    loss += [r'\addplot[gray,dashed,domain=0:40000,samples=2] {1};',
             r'\addlegendentry{Mass-balance limit}', r'\end{axis}', r'\end{tikzpicture}',
             r'\caption{Cumulative loss per addition after discarding the first 20,000 additions, averaged over three runs. The first 20,000 retained additions form the primary window. Both curves approach the mass-balance limit of one grain per addition.}',
             r'\label{fig:loss}',r'\end{figure}']
    (OUT/'loss_report.tex').write_text('\n'.join(loss)+'\n')

    profile = [r'\begin{figure}[htbp]',r'\centering',r'\begin{tikzpicture}',
               r'\begin{axis}[width=0.82\linewidth,height=4.0cm,xlabel={Column on the centre row},ylabel={Expected topplings per addition},xmin=1,xmax=31,ymin=0,ymax=85,grid=major,grid style={gray!15},tick label style={font=\small}]',
               r'\path[fill=amber!15] (axis cs:14.5,0) rectangle (axis cs:17.5,85);',
               r'\addplot[teal,thick,mark=*,mark size=1pt] coordinates {'+coordinates(np.arange(1,32),response[15,:])+'};',
               r'\end{axis}',r'\end{tikzpicture}',
               r'\caption{Theoretical response $q_x=(\Delta^{-1}\mathbf{1})_x$ for additions along the central row. The central patch is shaded. The response is calculated from the discrete Poisson equation. Greater distance from the sink raises the expected amount of redistribution.}',
               r'\label{fig:response}',r'\end{figure}']
    (OUT/'response_report.tex').write_text('\n'.join(profile)+'\n')
    for drive, group in report['groups'].items():
        print(drive, {key:group[key] for key in ('n','avalanches','S','mean_R_conditional','mean_D_positive','maxima')})
        for metric in ('S','A'):
            print(metric, group['tail_fits'][metric])
    print('Validated all 360,000 saved events and reproduced the primary summaries.')


if __name__ == '__main__':
    main()
