"""Independent audit of the saved report evidence (Python 3 + NumPy).

Run: python3 audit_project.py
Reads raw files and generated outputs; only writes results/audit_validation.json.
Uses synchronous array relaxation, independently constructed dense Poisson
equations, and direct raw-row statistics rather than the analysis helpers.
The legal-order equivalence is justified in main.tex Appendix A (Dhar/Jarai).
"""
from collections import Counter
import csv
import hashlib
from itertools import product
import json
import math
from pathlib import Path
import random
import re
import statistics

import numpy as np

from sandpile import Sandpile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results'
FIELDS = ['step', 'site', 'S', 'A', 'D', 'R', 'mass']
COL = {name: i for i, name in enumerate(FIELDS)}


def check(condition, message):
    """Keep audit checks active even when Python is invoked with -O."""
    if not condition:
        raise AssertionError(message)


def close(actual, expected, name, atol=1e-10, rtol=0):
    check(np.allclose(actual, expected, atol=atol, rtol=rtol), name)


def parallel_add(heights, site):
    """Mutate a stable square integer array using simultaneous bulk rounds.

    A round topples each site floor(height/4) times, then transfers all grains
    with array slices. Returns the five event metrics and a full count array.
    This shares neither neighbour lists nor queue/count code with Sandpile.add.
    """
    length = heights.shape[0]
    row, col = divmod(site, length)
    heights[row, col] += 1
    counts = np.zeros_like(heights)
    loss = 0
    while heights.max() >= 4:
        topples = heights // 4
        counts += topples
        loss += int(topples[0].sum() + topples[-1].sum()
                    + topples[:, 0].sum() + topples[:, -1].sum())
        heights -= 4 * topples
        heights[1:] += topples[:-1]
        heights[:-1] += topples[1:]
        heights[:, 1:] += topples[:, :-1]
        heights[:, :-1] += topples[:, 1:]
    occupied = np.argwhere(counts > 0)
    extent = int(np.abs(occupied - [row, col]).sum(axis=1).max()) if len(occupied) else 0
    return (int(counts.sum()), len(occupied), loss, extent, int(heights.sum())), counts


def rank_correlation(first, second):
    """Average tie ranks using frequency maps and the stdlib Pearson formula."""
    def ranks(values):
        seen, mapping = 0, {}
        for value, count in sorted(Counter(values).items()):
            mapping[value] = seen + (count + 1) / 2
            seen += count
        return [mapping[value] for value in values]
    return statistics.correlation(ranks(first), ranks(second))


def quantile(values, probability):
    ordered = sorted(values)
    index = (len(ordered) - 1) * probability
    lower = math.floor(index)
    fraction = index - lower
    return ordered[lower] + fraction * (ordered[min(lower+1, len(ordered)-1)] - ordered[lower])


def summarize(rows):
    """Recompute report metrics directly from integer rows, without helpers."""
    events = [row for row in rows if row[2] > 0]
    n = len(rows)
    result = {name: statistics.fmean(int(row[COL[name]]) for row in rows)
              for name in ('S', 'A', 'D', 'R', 'mass')}
    result.update(n=n, avalanches=len(events), height=result['mass']/961,
                  avalanche_probability=len(events)/n,
                  mean_S_conditional=sum(int(r[2]) for r in events)/len(events),
                  mean_A_conditional=sum(int(r[3]) for r in events)/len(events),
                  mean_R_conditional=sum(int(r[5]) for r in events)/len(events),
                  mean_S_over_A=statistics.fmean(r[2]/r[3] for r in events),
                  zero_D_conditional=sum(r[4] == 0 for r in events)/len(events),
                  zero_R_conditional=sum(r[5] == 0 for r in events)/len(events),
                  mean_D_positive=sum(int(r[4]) for r in rows)/sum(r[4] > 0 for r in rows),
                  positive_loss_count=sum(r[4] > 0 for r in rows),
                  positive_loss_probability=sum(r[4] > 0 for r in rows)/n,
                  maxima={k: max(int(r[COL[k]]) for r in rows) for k in ('S','A','D','R')},
                  S_quantiles_conditional={str(p): quantile([int(r[2]) for r in events], p)
                                          for p in (.5, .9, .99)},
                  spearman={})
    for pair in ('SA', 'SD', 'SR', 'AD', 'AR', 'DR'):
        result['spearman'][pair] = rank_correlation(
            [int(r[COL[pair[0]]]) for r in events], [int(r[COL[pair[1]]]) for r in events])
    return result


def nested_close(actual, saved, label, *, omit=()):
    """Compare every required metric; omit only explicitly named top-level fields."""
    for key, value in actual.items():
        if key in omit:
            continue
        if isinstance(value, dict):
            nested_close(value, saved[key], label+'.'+key)
        else:
            close(value, saved[key], label+'.'+key)


def plotted_series(name):
    text = (OUT / name).read_text()
    return [np.array([(float(x), float(y)) for x, y in re.findall(
        r'\(([^,()]+),([^,()]+)\)', block)])
        for block in re.findall(r'coordinates\s*\{([^}]*)\}', text)]


def check_core_comparison(groups):
    """Check all six bars and their printed labels against independent means.

    groups is the audit's independently recomputed uniform/biased summary.
    Missing, extra, reordered or incorrect bars/labels fail, including under -O.
    """
    filename = 'core_comparison_plot.tex'
    series = plotted_series(filename)
    expected = [(position, groups[drive][metric], precision)
                for metric, precision in [('S', 4), ('height', 5), ('D', 5)]
                for position, drive in [(1, 'uniform'), (2, 'biased')]]
    check(len(series) == len(expected), filename + ' bar count')
    labels = re.findall(
        r'\\node\[[^\]]*\]\s+at\s+\(axis cs:([^,]+),([^\)]+)\)\s*\{([^{}]*)\};',
        (OUT / filename).read_text())
    check(len(labels) == len(expected), filename + ' label count')
    for points, label, (position, value, precision) in zip(series, labels, expected):
        check(points.shape == (1, 2), filename + ' bar shape')
        close(points[0], [position, value], filename + ' bar value')
        close([float(label[0]), float(label[1])], [position, value], filename + ' label position')
        check(label[2] == f'{value:.{precision}f}', filename + ' printed label')
    return len(expected)


def audit_tail(values, saved):
    """Check MLEs by solving the score equation, with a longer zeta sum.

    Independent of the production golden-section objective search. Uses
    analytic derivatives of an Euler--Maclaurin tail starting at 100,000.
    """
    xmin = saved['xmin']
    sample = values[values >= xmin]
    target = float(np.log(sample).mean())
    stop = 100000
    logs = np.log(np.arange(xmin, stop, dtype=float))
    log_stop = math.log(stop)
    def normalization(alpha):
        terms = np.exp(-alpha*logs)
        integral = stop**(1-alpha)/(alpha-1)
        half = .5*stop**(-alpha)
        correction = alpha/12*stop**(-alpha-1)
        z = float(terms.sum()) + integral + half + correction
        negative_derivative = (float((terms*logs).sum())
            + integral*(log_stop+1/(alpha-1)) + half*log_stop
            + stop**(-alpha-1)/12*(alpha*log_stop-1))
        return z, negative_derivative/z
    lower, upper = 1.01, 8.0
    for _ in range(50):
        middle = (lower+upper)/2
        if normalization(middle)[1] > target:
            lower = middle
        else:
            upper = middle
    alpha = (lower+upper)/2
    close(alpha, saved['alpha'], 'tail exponent score root', atol=2e-6)
    grid = np.arange(xmin, int(sample.max())+1)
    empirical = np.searchsorted(np.sort(sample), grid, side='right')/len(sample)
    model = np.cumsum(grid.astype(float)**(-alpha))/normalization(alpha)[0]
    excess = sample-xmin
    q = len(sample)/(len(sample)+int(excess.sum()))
    geometric = -np.expm1((grid-xmin+1)*math.log1p(-q))
    ll_power = -alpha*float(np.log(sample).sum())-len(sample)*math.log(normalization(alpha)[0])
    ll_geom = len(sample)*math.log(q)+int(excess.sum())*math.log1p(-q)
    check(len(sample) == saved['n'], 'tail sample count')
    close(q, saved['geometric_q'], 'geometric MLE')
    close(np.max(np.abs(empirical-model)), saved['ks_power'], 'power CDF distance', atol=1e-6)
    close(np.max(np.abs(empirical-geometric)), saved['ks_geometric'], 'geometric CDF distance')
    close((ll_power-ll_geom)/len(sample), saved['log_likelihood_difference_per_event'], 'tail likelihood', atol=1e-9)


def check_table(filename, expected):
    """Verify all visible numeric cells, including their displayed rounding."""
    body = (OUT/filename).read_text().split(r'\midrule')[1].split(r'\bottomrule')[0]
    actual = [[cell.strip() for cell in line.removesuffix('\\\\').split('&')]
              for line in body.strip().splitlines()]
    check(len(actual) == len(expected), filename+' row count')
    for cells, numbers in zip(actual, expected):
        check(cells[-len(numbers):] == numbers, filename+' numeric cells '+str(cells))


def main():
    # Exhaust all stable 2x2 states and additions; also stress the actual size.
    cases = [(2, list(h), site) for h in product(range(4), repeat=4) for site in range(4)]
    rng = random.Random(42017)
    for site in (0, 15, 480, 945, 960):
        cases.append((31, [3]*961, site))
    for _ in range(20):
        cases.append((31, [rng.randrange(4) for _ in range(961)], rng.randrange(961)))
    for length, initial, site in cases:
        h = np.array(initial, dtype=np.int64).reshape(length, length)
        event, counts = parallel_add(h, site)
        for order in ('queue', 'stack'):
            pile = Sandpile(length, initial)
            metrics, sparse = pile.add(site, order)
            check(metrics == event and pile.h == h.ravel().tolist(), 'independent relaxation')
            check(sparse == {i: int(n) for i, n in enumerate(counts.ravel()) if n}, 'toppling counts')

    # Assemble the graph matrix directly from coordinate distances.
    xy = np.array(list(product(range(31), repeat=2)))
    adjacency = (np.abs(xy[:, None] - xy[None, :]).sum(axis=2) == 1).astype(float)
    matrix = 4*np.eye(961) - adjacency
    response = np.linalg.solve(matrix, np.ones(961))
    uniform = np.full(961, 1/961)
    patch = [r*31+c for r in (14,15,16) for c in (14,15,16)]
    biased = .2 * uniform
    biased[patch] += .8 / 9
    benchmark = json.loads((ROOT/'benchmark_results.json').read_text())
    predictions = {'uniform': float(uniform@response), 'biased': float(biased@response)}
    for drive, key in [('uniform','uniform'),('biased','centre_biased')]:
        close(predictions[drive], benchmark['cases'][key]['mean_topplings_per_addition'], 'Poisson mean')
    close(predictions['biased']/predictions['uniform'], benchmark['toppling_mean_ratio'], 'Poisson ratio')

    raw, source_checks, weighted = {'uniform': [], 'biased': []}, [], []
    prior_hashes = {x['file']: x['sha256'] for x in json.loads((OUT/'replay_validation.json').read_text())['checks']}
    for mode in ('production', 'pilot'):
        metadata = json.loads((OUT/f'{mode}_metadata.json').read_text())
        expected_seeds = {'uniform': [101,102,103], 'biased': [201,202,203]} if mode == 'production' else {'uniform':[1101], 'biased':[1201]}
        check(sorted((r['drive'], r['seed']) for r in metadata['runs']) ==
              sorted((d,s) for d,seeds in expected_seeds.items() for s in seeds), 'seed inventory')
        for run in metadata['runs']:
            path = OUT/run['csv']
            with path.open(newline='') as stream:
                reader = csv.reader(stream)
                check(next(reader) == FIELDS, path.name+' schema')
                rows = [tuple(int(value) for value in row) for row in reader]
            check(len(rows) == run['additions'], path.name+' length')
            h = np.zeros((31,31), dtype=np.int64)
            generator = random.Random(run['seed'])
            endpoints = {0: 0.0}
            total_topples = 0
            for step, row in enumerate(rows, 1):
                site = (generator.choice(patch) if run['drive']=='biased' and generator.random()<.8
                        else generator.randrange(961))
                check(row[:2] == (step, site), path.name+' input site/step')
                event, _ = parallel_add(h, site)
                check(event == row[2:], f'{path.name} event {step}: {event} != {row[2:]}')
                total_topples += event[0]
                if step in (10000,20000,30000,40000,60000):
                    endpoints[step] = float(response@h.ravel())
            check(total_topples == run['topplings'], path.name+' toppling total')
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if mode == 'production':
                check(digest == prior_hashes[path.name], path.name+' source hash')
                raw[run['drive']].append(np.array(rows, dtype=np.int64))
                selected = rows[20000:40000]
                input_term = statistics.fmean(response[row[1]] for row in selected)
                endpoint_term = (endpoints[20000]-endpoints[40000])/20000
                observed = sum(row[2] for row in selected)/20000
                close(input_term+endpoint_term, observed, 'weighted event balance')
                weighted.append(dict(file=path.name, mean_S=observed,
                                     mean_input_response=input_term, endpoint_correction=endpoint_term))
            source_checks.append(dict(file=path.name, rows=len(rows), sha256=digest,
                                      all_metrics_match_independent_relaxation=True))
            print(path.name, len(rows), 'independent events passed', flush=True)

    primary = {drive: np.concatenate([r[20000:40000] for r in runs]) for drive, runs in raw.items()}
    analysis = json.loads((OUT/'analysis.json').read_text())
    extra = json.loads((OUT/'report_analysis.json').read_text())
    linear_response = dict(uniform_mean=predictions['uniform'],
                           patch_mean=float(response[patch].mean()),
                           slope=float(response[patch].mean())-predictions['uniform'])
    for key, value in linear_response.items():
        close(value, extra['linear_response'][key], 'linear response '+key)
    close(linear_response['uniform_mean']+.8*linear_response['slope'],
          predictions['biased'], 'linear response at recorded bias')
    linear_tex = (OUT/'linear_response_report.tex').read_text()
    check((rf'\E_w[S]\simeq {linear_response["uniform_mean"]:.8f}'
           rf'+{linear_response["slope"]:.8f}\,w') in linear_tex,
          'rounded linear-response coefficients')
    check(rf'\E_C[S]\simeq {linear_response["patch_mean"]:.8f}' in linear_tex,
          'rounded patch response')
    check(r'0\leq w<1' in linear_tex, 'linear-response domain')
    groups = {}
    mean_response_decomposition = {}
    # These five metrics are present only in report_analysis.json. All other
    # recomputed fields, including nested correlations, are required in both.
    extended_metrics = ('mean_R_conditional', 'mean_D_positive',
                        'positive_loss_count', 'positive_loss_probability', 'maxima')
    for drive, rows in primary.items():
        groups[drive] = summarize(rows)
        nested_close(groups[drive], analysis['groups'][drive], drive, omit=extended_metrics)
        nested_close(groups[drive], extra['groups'][drive], drive)
        close(groups[drive]['positive_loss_probability'],
              extra['groups'][drive]['positive_loss_probability'], 'positive-loss probability')
        close(groups[drive]['positive_loss_probability'],
              groups[drive]['avalanche_probability']*(1-groups[drive]['zero_D_conditional']),
              'positive-loss frequency decomposition')
        close(groups[drive]['positive_loss_probability']*groups[drive]['mean_D_positive'],
              groups[drive]['D'], 'mean-loss decomposition')
        # These endpoint values came from the independently replayed full grids.
        runs = [item for item in weighted if item['file'].startswith('production_'+drive+'_')]
        input_mean = statistics.fmean(item['mean_input_response'] for item in runs)
        endpoint = statistics.fmean(item['endpoint_correction'] for item in runs)
        terms = dict(theoretical_mean=predictions[drive],
                     mean_minus_theory=groups[drive]['S']-predictions[drive],
                     mean_input_response=input_mean,
                     input_sampling_term=input_mean-predictions[drive], endpoint_term=endpoint)
        saved_terms = extra['mean_response_decomposition'][drive]
        for key, value in terms.items():
            close(value, saved_terms[key], 'mean-response decomposition '+drive+'.'+key)
        close(terms['input_sampling_term']+terms['endpoint_term'],
              terms['mean_minus_theory'], 'deviation decomposition closure')
        check(len(saved_terms['runs']) == len(runs), 'decomposition run count')
        for actual, saved_run in zip(runs, saved_terms['runs']):
            check(actual['file'] == saved_run['file'], 'decomposition run identity')
            for key in ('mean_S','mean_input_response'):
                close(actual[key], saved_run[key], 'per-run decomposition '+key)
            close(actual['endpoint_correction'], saved_run['endpoint_term'],
                  'endpoint residual versus independently replayed grids')
        mean_response_decomposition[drive] = terms
        close(sum(row[1] in patch for row in rows)/len(rows), analysis['groups'][drive]['patch_frequency'], 'patch frequency')
        for index, run in enumerate(raw[drive]):
            nested_close(summarize(run[20000:40000]), analysis['groups'][drive]['runs'][index],
                         'seed summary', omit=extended_metrics)
        for start, end in [(10000,30000),(40000,60000),(20000,60000)]:
            subset = np.concatenate([r[start:end] for r in raw[drive]])
            nested_close(summarize(subset), analysis['groups'][drive]['sensitivity'][f'{start+1}-{end}'],
                         'window summary', omit=extended_metrics)
        for block in (500,1000,2000,5000):
            variances = []
            for run in raw[drive]:
                means = [sum(int(row[2]) for row in run[k:k+block])/block for k in range(20000,40000,block)]
                variances.append(statistics.variance(means)/len(means))
            close(math.sqrt(sum(variances))/3, analysis['groups'][drive]['block_se_S'][str(block)], 'block SE')

    # Check every plotted coordinate against its actual input rows.
    plot_checks = {'core_comparison_plot.tex': check_core_comparison(groups)}
    series = plotted_series('distribution_plot.tex')
    for i, metric in enumerate(('S','A','D','R')):
        for j, drive in enumerate(('uniform','biased')):
            points = series[2*i+j]
            events = primary[drive][primary[drive][:,2]>0, COL[metric]]
            expected = [np.count_nonzero(events >= x)/len(events) for x in points[:,0]]
            close(points[:,1], expected, 'CCDF '+metric, atol=5e-8, rtol=5e-7)
    plot_checks['distribution_plot.tex'] = sum(map(len,series))
    for filename in ('height_plot.tex','loss_report.tex','activity_plot.tex'):
        series = plotted_series(filename)
        for j, drive in enumerate(('uniform','biased')):
            points = series[j]
            if filename == 'height_plot.tex':
                expected = [statistics.fmean(int(v) for run in raw[drive] for v in run[k:k+1000,6])/961
                            for k in range(0,60000,1000)]
                close(points[:,0], np.arange(500,60000,1000), 'height x')
            elif filename == 'loss_report.tex':
                expected = [sum(int(v) for run in raw[drive] for v in run[20000:20000+int(n),4])/(3*n)
                            for n in points[:,0]]
            else:
                bins = json.loads((OUT/'activity_bins.json').read_text())[drive]
                expected, xvalues, counts = [], [], []
                for lo, hi in zip(bins['edges'][:-1], bins['edges'][1:]):
                    rows = primary[drive]
                    selected = rows[(rows[:,3]>=lo)&(rows[:,3]<hi)]
                    if len(selected):
                        xvalues.append(sum(int(v) for v in selected[:,3])/len(selected))
                        expected.append(sum(int(v) for v in selected[:,2])/len(selected))
                        counts.append(len(selected))
                close(points[:,0], xvalues, 'activity x', atol=5e-5, rtol=5e-7)
                check(counts == bins['counts'], 'activity bin counts')
            close(points[:,1], expected, filename, atol=5e-5, rtol=5e-7)
        plot_checks[filename] = sum(map(len,series))
    profile = plotted_series('response_report.tex')[0]
    close(profile[:,0], range(1,32), 'response columns')
    close(profile[:,1], response.reshape(31,31)[15], 'response plot', atol=5e-5)
    plot_checks['response_report.tex'] = len(profile)

    for drive in primary:
        for metric in ('S','A'):
            for fit in extra['groups'][drive]['tail_fits'][metric]:
                audit_tail(primary[drive][:, COL[metric]], fit)
    # All eight numeric tables are checked after independent recomputation above.
    pair = [analysis['groups'][drive] for drive in ('uniform','biased')]
    metric_rows = []
    for key, precision in [('avalanche_probability',5),
                           ('mean_S_conditional',2),('mean_A_conditional',2),('mean_S_over_A',4),
                           ('zero_D_conditional',4),('zero_R_conditional',4)]:
        metric_rows.append([f'{g[key]:.{precision}f}' for g in pair])
    for probability, precision in [('0.5',0),('0.99',1)]:
        metric_rows.append([f'{g["S_quantiles_conditional"][probability]:.{precision}f}' for g in pair])
    check_table('metrics_table.tex', metric_rows)
    check_table('run_table.tex', [[str(base+i),f'{run["S"]:.5f}',f'{run["height"]:.5f}']
        for drive,base in [('uniform',101),('biased',201)]
        for i,run in enumerate(analysis['groups'][drive]['runs'])])
    sensitivity = []
    for window in ('10001-30000','20001-40000','40001-60000','20001-60000'):
        u,b = [g['S'] if window=='20001-40000' else g['sensitivity'][window]['S'] for g in pair]
        sensitivity.append([f'{u:.4f}',f'{b:.4f}',f'{b/u:.4f}'])
    check_table('sensitivity_table.tex', sensitivity)
    check_table('block_table.tex', [[str(block)]+[f'{g["block_se_S"][str(block)]:.4f}' for g in pair]
                                  for block in (500,1000,2000,5000)])
    check_table('correlations_table.tex', [[f'{g["spearman"][p]:.4f}' for g in pair]
                                         for p in ('SA','SD','SR','AD','AR','DR')])
    check_table('tail_report.tex', [[str(f['xmin']), str(f['n']), f'{f["alpha"]:.3f}',
        f'{f["ks_power"]:.3f}', f'{f["ks_geometric"]:.3f}',
        f'{f["log_likelihood_difference_per_event"]:.5f}']
        for metric in ('S','A') for drive in ('uniform','biased')
        for f in extra['groups'][drive]['tail_fits'][metric] if f['xmin'] in (20,100)])
    check_table('mean_error_report.tex',
                [[f'{mean_response_decomposition[drive][key]:.6f}'
                  for key in ('mean_minus_theory','input_sampling_term','endpoint_term')]
                 for drive in ('uniform','biased')])
    check_table('dissipation_report.tex',
                [[f'{groups[drive][key]:.6f}'
                  for key in ('positive_loss_probability','mean_D_positive','D')]
                 for drive in ('uniform','biased')])

    result = dict(independent_dynamics_cases=len(cases), source_checks=source_checks,
                  total_events=sum(row['rows'] for row in source_checks),
                  benchmark=predictions, groups=groups,
                  mean_S_ratio=groups['biased']['S']/groups['uniform']['S'],
                  weighted_balance=weighted, every_plot_coordinate_checked=plot_checks,
                  independently_checked_tail_fits=16, numeric_tables_checked=8,
                  linear_response=linear_response,
                  mean_response_decomposition=mean_response_decomposition,
                  checks='all passed; no production analysis helpers used')
    def scalar(value):
        if isinstance(value, np.generic):
            return value.item()
        raise TypeError(type(value).__name__)
    (OUT/'audit_validation.json').write_text(json.dumps(result,indent=2,default=scalar)+'\n')
    print(json.dumps({k: result[k] for k in ('independent_dynamics_cases','total_events','mean_S_ratio','every_plot_coordinate_checked')},indent=2))


if __name__ == '__main__':
    main()
