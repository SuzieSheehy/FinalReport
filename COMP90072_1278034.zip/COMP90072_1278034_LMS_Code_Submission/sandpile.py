"""Reproducible BTW experiment for the report (Python standard library only).

The threshold is four at every site. Each missing neighbour is a sink edge.
Abelian stabilisation reference: Jarai, Sandpile models (2018), section 2.1,
https://arxiv.org/abs/1401.0354. All events, including zero events, are saved.

Usage examples:
  python3 sandpile.py pilot
  python3 sandpile.py production --burn-in 20000 --samples 40000
  python3 sandpile.py timing
"""

import argparse
from collections import deque
import csv
import json
from numbers import Integral
from pathlib import Path
import platform
import random
import statistics
import time

ROOT = Path(__file__).resolve().parent
FIELDS = ['step', 'site', 'S', 'A', 'D', 'R', 'mass']


def _integer(name, value, minimum=0, maximum=None):
    """Validate a discrete quantity without truncating floats or accepting bools."""
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f'{name} must be an integer (not bool)')
    value = int(value)
    if value < minimum or (maximum is not None and value > maximum):
        bound = f'between {minimum} and {maximum}' if maximum is not None else f'at least {minimum}'
        raise ValueError(f'{name} must be {bound}')
    return value


def _choice(name, value, choices):
    """Reject unknown rule names instead of silently selecting another rule."""
    if not isinstance(value, str):
        raise TypeError(f'{name} must be a string')
    if value not in choices:
        raise ValueError(f'{name} must be one of {choices}')


def _stable_heights(heights, length):
    """Return a validated copy of a flat, stable integer configuration."""
    values = list(heights)
    if len(values) != length * length:
        raise ValueError('heights must contain exactly length * length entries')
    return [_integer('height', value, maximum=3) for value in values]


class Sandpile:
    """Stable grid with FIFO or LIFO relaxation and exact integer event counts.

    length is a positive integer; heights is an optional flat iterable of
    length**2 integers in [0, 3], copied on construction. Invalid types raise
    TypeError; invalid values raise ValueError. Treat h, mass and queued as
    internal state: use add() to evolve a constructed grid.
    """

    def __init__(self, length=31, heights=None):
        length = _integer('length', length, minimum=1)
        self.length = length
        self.h = [0] * (length * length) if heights is None else _stable_heights(heights, length)
        self.mass = sum(self.h)
        self.xy = [divmod(i, length) for i in range(length * length)]
        self.neighbours = []
        for row, col in self.xy:
            self.neighbours.append(tuple(
                rr * length + cc if 0 <= rr < length and 0 <= cc < length else -1
                for rr, cc in [(row-1, col), (row+1, col), (row, col-1), (row, col+1)]
            ))
        self.queued = [False] * len(self.h)

    def add(self, site, order='queue'):
        """Add at a flat site index; return (S,A,D,R,mass), sitewise topplings.

        Queue membership is reset on removal. Each pop performs one legal
        toppling; sites still unstable are requeued. The per-event dictionary
        avoids clearing an L-by-L array to count distinct toppled sites.
        site must be an integer in [0, length**2); order is 'queue' or 'stack'.
        Invalid arguments raise TypeError/ValueError before any state changes.
        """
        site = _integer('site', site, maximum=len(self.h)-1)
        _choice('order', order, ('queue', 'stack'))
        heights, neighbours, queued = self.h, self.neighbours, self.queued
        heights[site] += 1
        self.mass += 1
        counts = {}
        loss = 0
        work = deque()
        if heights[site] >= 4:
            work.append(site)
            queued[site] = True
        while work:
            i = work.popleft() if order == 'queue' else work.pop()
            queued[i] = False
            if heights[i] < 4:
                continue
            heights[i] -= 4
            counts[i] = counts.get(i, 0) + 1
            for j in neighbours[i]:
                if j < 0:
                    loss += 1
                else:
                    heights[j] += 1
                    if heights[j] >= 4 and not queued[j]:
                        work.append(j)
                        queued[j] = True
            if heights[i] >= 4 and not queued[i]:
                work.append(i)
                queued[i] = True
        self.mass -= loss
        row, col = self.xy[site]
        extent = max((abs(self.xy[i][0]-row) + abs(self.xy[i][1]-col)
                      for i in counts), default=0)
        return (sum(counts.values()), len(counts), loss, extent, self.mass), counts


def scan_add(heights, length, site):
    """Independent reference: repeatedly scan the whole grid for legal sites.

    Mutates a flat list of heights and returns the same event measurements and
    per-site counts as Sandpile.add. Deliberately favours clarity over speed.
    Requires a stable integer list and the same length/site bounds as Sandpile.
    Validation finishes before mutation; invalid inputs raise TypeError/ValueError.
    """
    length = _integer('length', length, minimum=1)
    site = _integer('site', site, maximum=length*length-1)
    if not isinstance(heights, list):
        raise TypeError('heights must be a mutable flat list')
    values = _stable_heights(heights, length)
    heights[:] = values
    return _scan_add_validated(heights, length, site)


def _scan_add_validated(heights, length, site):
    """Scan relaxation for already validated internal inputs (including timing)."""
    heights[site] += 1
    counts, loss = {}, 0
    while True:
        changed = False
        for i in range(length * length):
            if heights[i] < 4:
                continue
            changed = True
            heights[i] -= 4
            counts[i] = counts.get(i, 0) + 1
            row, col = divmod(i, length)
            for rr, cc in [(row-1, col), (row+1, col), (row, col-1), (row, col+1)]:
                if 0 <= rr < length and 0 <= cc < length:
                    heights[rr * length + cc] += 1
                else:
                    loss += 1
        if not changed:
            break
    row, col = divmod(site, length)
    extent = max((abs(i//length-row) + abs(i % length-col) for i in counts), default=0)
    return (sum(counts.values()), len(counts), loss, extent, sum(heights)), counts


def addition_sites(drive, seed, count, length=31):
    """Return a seeded site iterator; validate arguments immediately.

    drive is 'uniform' or 'biased'; length >= 1 (>= 3 for the central patch),
    count >= 0. Discrete arguments must be integers, excluding bools. seed
    follows random.Random's accepted types. The uniform branch includes C.
    """
    _choice('drive', drive, ('uniform', 'biased'))
    length = _integer('length', length, minimum=3 if drive == 'biased' else 1)
    count = _integer('count', count)
    rng = random.Random(seed)
    centre = length // 2
    patch = [(centre+dr)*length+centre+dc for dr in (-1,0,1) for dc in (-1,0,1)]
    def sites():
        for _ in range(count):
            yield rng.choice(patch) if drive == 'biased' and rng.random() < .8 else rng.randrange(length*length)
    return sites()


def simulate(drive, seed, count, output, burn_in):
    """Simulate from empty; time generation, relaxation and periodic checks.

    Use the fixed 31-by-31 grid, a 'uniform' or 'biased' drive, and a seed
    accepted by random.Random. Save all count additions to the CSV, including
    the burn-in rows. burn_in is recorded in metadata; the analysis scripts
    select the actual retained window later. output's parent must exist.
    Return a metadata dictionary containing drive, seed, addition/burn-in
    counts, elapsed seconds, total topplings, checked-state count and CSV name.

    CSV serialisation is outside the timed region. Full-grid stability, exact
    mass and queue state are independently checked every 1000 additions.
    count must be positive and 0 <= burn_in < count. output is a path-like
    CSV destination. Invalid model/sampling arguments do not touch that file.
    """
    count = _integer('count', count, minimum=1)
    burn_in = _integer('burn_in', burn_in, maximum=count-1)
    sites = addition_sites(drive, seed, count)
    output = Path(output)
    pile = Sandpile()
    rows = []
    started = time.perf_counter()
    for step, site in enumerate(sites, 1):
        metrics, _ = pile.add(site)
        s, a, d, r, mass = metrics
        assert 0 <= a <= min(s, 961)
        rows.append((step, site, *metrics))
        if step % 1000 == 0 or step == count:
            assert all(0 <= h <= 3 for h in pile.h)
            assert sum(pile.h) == mass
            assert not any(pile.queued)
    elapsed = time.perf_counter() - started
    with output.open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(FIELDS)
        writer.writerows(rows)
    return dict(drive=drive, seed=seed, additions=count, burn_in=burn_in,
                elapsed_seconds=elapsed, topplings=sum(row[2] for row in rows),
                checked_states=(count+999)//1000, csv=output.name)


def timing():
    """Compare algorithms on identical stable inputs and identical additions.

    Both algorithms compute all event metrics. Five repeats start from copies
    of one warmed state; equality is checked before reporting median runtimes.
    """
    length = 15
    warm = Sandpile(length)
    for site in addition_sites('uniform', 9001, 5000, length):
        warm.add(site)
    sites = list(addition_sites('uniform', 9002, 3000, length))
    durations = {'queue': [], 'scan': []}
    events = {}
    for _ in range(5):
        for algorithm in ('queue', 'scan'):
            pile = Sandpile(length, warm.h)
            outputs = []
            started = time.perf_counter()
            for site in sites:
                # The constructor and generator validate these internal inputs.
                # Avoid repeating a full-grid input check inside the scan timer.
                result, _ = pile.add(site) if algorithm == 'queue' else _scan_add_validated(pile.h, length, site)
                outputs.append(result)
            durations[algorithm].append(time.perf_counter()-started)
            events[algorithm] = outputs
        assert events['queue'] == events['scan']
    return dict(length=length, additions=len(sites), repeats=5,
                warmup_seed=9001, timed_seed=9002,
                total_topplings=sum(row[0] for row in events['queue']),
                seconds=durations,
                median_seconds={k: statistics.median(v) for k,v in durations.items()},
                identical_event_metrics=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['pilot', 'production', 'timing'])
    parser.add_argument('--burn-in', type=int, default=20000)
    parser.add_argument('--samples', type=int, default=40000)
    args = parser.parse_args()
    if args.burn_in < 0:
        parser.error('--burn-in must be nonnegative')
    if args.samples <= 0:
        parser.error('--samples must be positive')
    output = ROOT/'results'
    output.mkdir(exist_ok=True)
    metadata = dict(python=platform.python_version(), machine=platform.machine(),
                    platform=platform.platform(), rng='random.Random / MT19937', mode=args.mode)
    if args.mode == 'timing':
        metadata.update(timing())
    else:
        seeds = {'uniform': [101,102,103], 'biased': [201,202,203]}
        if args.mode == 'pilot':
            seeds = {'uniform': [1101], 'biased': [1201]}
        count = 30000 if args.mode == 'pilot' else args.burn_in + args.samples
        metadata['runs'] = []
        for drive, run_seeds in seeds.items():
            for seed in run_seeds:
                path = output/f'{args.mode}_{drive}_{seed}.csv'
                result = simulate(drive, seed, count, path, args.burn_in if args.mode == 'production' else 0)
                metadata['runs'].append(result)
                print(json.dumps(result), flush=True)
    destination = output/f'{args.mode}_metadata.json'
    destination.write_text(json.dumps(metadata, indent=2)+'\n')
    print(destination)


if __name__ == '__main__':
    main()
