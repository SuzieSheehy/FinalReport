"""Replay every saved production event without overwriting the source CSVs.

Run: python3 verify_saved_results.py
Uses only the Python standard library. Records hashes and event-by-event
agreement in results/replay_validation.json. Checks also run under python -O.
Runtime is machine dependent.
"""
import csv
import hashlib
import json
import platform
from pathlib import Path

from sandpile import Sandpile, addition_sites

ROOT = Path(__file__).resolve().parent


def check(condition, message):
    """Reject a mismatch even when Python disables assert statements."""
    if not condition:
        raise AssertionError(message)


def main():
    metadata = json.loads((ROOT/'results/production_metadata.json').read_text())
    checks = []
    for run in metadata['runs']:
        source = ROOT/'results'/run['csv']
        pile = Sandpile()
        with source.open(newline='') as stream:
            rows = list(csv.DictReader(stream))
        check(len(rows) == run['additions'], f'{source.name}: row count mismatch')
        for step, (row, site) in enumerate(zip(rows, addition_sites(
                run['drive'], run['seed'], run['additions'])), 1):
            metrics, _ = pile.add(site)
            expected = tuple(int(row[key]) for key in ('S','A','D','R','mass'))
            check(int(row['step']) == step and int(row['site']) == site,
                  f'{source.name}, event {step}: step or input site mismatch')
            check(metrics == expected,
                  f'{source.name}, event {step}: replay {metrics} != saved {expected}')
            if step % 1000 == 0:
                check(all(0 <= height <= 3 for height in pile.h),
                      f'{source.name}, event {step}: unstable grid')
                check(sum(pile.h) == pile.mass and not any(pile.queued),
                      f'{source.name}, event {step}: mass or queue mismatch')
        checks.append(dict(file=source.name, events=len(rows), seed=run['seed'],
                           sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                           all_sites_and_metrics_match=True))
        print(source.name, len(rows), 'events reproduced', flush=True)
    result = dict(python=platform.python_version(), checks=checks,
                  total_events=sum(check['events'] for check in checks))
    (ROOT/'results/replay_validation.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__ == '__main__':
    main()
